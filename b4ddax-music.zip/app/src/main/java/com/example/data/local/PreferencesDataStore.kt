package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "b4ddax_user_preferences")

class PreferencesDataStore(private val context: Context) {

    private val KEY_AUTO_RESUME = booleanPreferencesKey("pref_auto_resume")
    private val KEY_LAST_TRACK_ID = stringPreferencesKey("pref_last_track_id")
    private val KEY_LAST_TRACK_TITLE = stringPreferencesKey("pref_last_track_title")
    private val KEY_HIGH_QUALITY_SYNC = booleanPreferencesKey("pref_high_quality_sync")

    val autoResumeFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_AUTO_RESUME] ?: true
    }

    val highQualitySyncFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_HIGH_QUALITY_SYNC] ?: true
    }

    val lastTrackInfoFlow: Flow<Pair<String?, String?>> = context.dataStore.data.map { prefs ->
        Pair(prefs[KEY_LAST_TRACK_ID], prefs[KEY_LAST_TRACK_TITLE])
    }

    suspend fun setAutoResume(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_AUTO_RESUME] = enabled
        }
    }

    suspend fun setHighQualitySync(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_HIGH_QUALITY_SYNC] = enabled
        }
    }

    suspend fun saveLastTrack(trackId: String, title: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LAST_TRACK_ID] = trackId
            prefs[KEY_LAST_TRACK_TITLE] = title
        }
    }
}
