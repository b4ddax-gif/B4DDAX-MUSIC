package com.example.data.repository

import android.content.Context
import com.example.core.network.PlayRequestBody
import com.example.core.network.SpotifyApi
import com.example.core.utils.IntentUtils
import com.example.domain.model.PlayerStateModel
import com.example.domain.model.RepeatMode
import com.example.domain.model.SpotifyConnectionState
import com.example.domain.model.TrackModel
import com.example.domain.repository.SpotifyAuthRepository
import com.example.domain.repository.SpotifyPlayerController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SpotifyPlayerRepositoryImpl(
    private val context: Context,
    private val spotifyApi: SpotifyApi,
    private val authRepository: SpotifyAuthRepository,
    private val externalScope: CoroutineScope
) : SpotifyPlayerController {

    private val _connectionState = MutableStateFlow(SpotifyConnectionState.NOT_CONNECTED)
    override val connectionState: StateFlow<SpotifyConnectionState> = _connectionState.asStateFlow()

    private val _playerState = MutableStateFlow(PlayerStateModel())
    override val playerState: StateFlow<PlayerStateModel> = _playerState.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    override val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    override val isSpotifyInstalled: Boolean
        get() = IntentUtils.isSpotifyInstalled(context)

    private var pollingJob: Job? = null
    private var progressTickerJob: Job? = null

    init {
        // Observe authentication state to update connection status
        externalScope.launch {
            authRepository.isAuthenticated.collectLatest { authenticated ->
                if (!authenticated && _connectionState.value == SpotifyConnectionState.CONNECTED) {
                    _connectionState.value = SpotifyConnectionState.AUTH_REQUIRED
                    stopPolling()
                } else if (authenticated && _connectionState.value == SpotifyConnectionState.AUTH_REQUIRED) {
                    connect()
                }
            }
        }
    }

    override fun connect() {
        if (!isSpotifyInstalled) {
            _connectionState.value = SpotifyConnectionState.SPOTIFY_NOT_INSTALLED
            _errorMessage.value = "Spotify is not installed on this device."
            return
        }

        if (!authRepository.isAuthenticated.value) {
            _connectionState.value = SpotifyConnectionState.AUTH_REQUIRED
            return
        }

        _connectionState.value = SpotifyConnectionState.CONNECTING
        _errorMessage.value = null

        externalScope.launch {
            try {
                // Verify access & fetch initial playback state
                val response = withContext(Dispatchers.IO) { spotifyApi.getPlaybackState() }
                if (response.isSuccessful || response.code() == 204) {
                    _connectionState.value = SpotifyConnectionState.CONNECTED
                    if (response.body() != null) {
                        updatePlayerStateFromDto(response.body()!!)
                    }
                    startPolling()
                } else if (response.code() == 403) {
                    _connectionState.value = SpotifyConnectionState.PREMIUM_REQUIRED
                    _errorMessage.value = "Spotify Premium is required for full remote playback control."
                } else {
                    _connectionState.value = SpotifyConnectionState.CONNECTED
                    startPolling()
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                _connectionState.value = SpotifyConnectionState.CONNECTION_ERROR
                _errorMessage.value = "Could not connect to Spotify: ${e.localizedMessage ?: "Unknown error"}"
            }
        }
    }

    override fun disconnect() {
        stopPolling()
        _connectionState.value = SpotifyConnectionState.NOT_CONNECTED
    }

    override fun subscribeToPlayerState() {
        if (_connectionState.value == SpotifyConnectionState.CONNECTED && pollingJob == null) {
            startPolling()
        }
    }

    override fun clearError() {
        _errorMessage.value = null
    }

    override fun openSpotifyApp() {
        IntentUtils.openSpotifyApp(context)
    }

    override fun openSpotifyTrack(uri: String) {
        IntentUtils.openSpotifyUri(context, uri)
    }

    override fun installSpotify() {
        IntentUtils.openPlayStoreForSpotify(context)
    }

    override fun getPlayerState(): PlayerStateModel = _playerState.value

    override fun play(uri: String) {
        externalScope.launch {
            try {
                val isTrack = uri.startsWith("spotify:track:")
                val body = if (isTrack) {
                    PlayRequestBody(uris = listOf(uri))
                } else {
                    PlayRequestBody(contextUri = uri)
                }

                val response = withContext(Dispatchers.IO) {
                    spotifyApi.startPlayback(body)
                }

                if (response.isSuccessful) {
                    // Update state optimistically and poll immediately
                    _playerState.value = _playerState.value.copy(isPlaying = true)
                    delay(400)
                    syncPlaybackState()
                } else {
                    handlePlaybackApiError(response.code(), uri)
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                // Fallback to opening Spotify app with target URI
                IntentUtils.openSpotifyUri(context, uri)
                _errorMessage.value = "Open Spotify to continue playback."
            }
        }
    }

    override fun pause() {
        externalScope.launch {
            try {
                val response = withContext(Dispatchers.IO) { spotifyApi.pausePlayback() }
                if (response.isSuccessful) {
                    _playerState.value = _playerState.value.copy(isPlaying = false)
                    stopProgressTicker()
                } else {
                    handlePlaybackApiError(response.code(), null)
                }
            } catch (_: Exception) {
                _playerState.value = _playerState.value.copy(isPlaying = false)
            }
        }
    }

    override fun resume() {
        externalScope.launch {
            try {
                val response = withContext(Dispatchers.IO) { spotifyApi.startPlayback(null) }
                if (response.isSuccessful) {
                    _playerState.value = _playerState.value.copy(isPlaying = true)
                    startProgressTicker()
                } else {
                    handlePlaybackApiError(response.code(), null)
                }
            } catch (_: Exception) {
                IntentUtils.openSpotifyApp(context)
                _errorMessage.value = "Open Spotify to continue playback."
            }
        }
    }

    override fun togglePlayPause() {
        if (_playerState.value.isPlaying) {
            pause()
        } else {
            resume()
        }
    }

    override fun skipNext() {
        if (!_playerState.value.canSkipNext) return
        externalScope.launch {
            try {
                val response = withContext(Dispatchers.IO) { spotifyApi.skipToNext() }
                if (response.isSuccessful) {
                    delay(300)
                    syncPlaybackState()
                } else {
                    handlePlaybackApiError(response.code(), null)
                }
            } catch (_: Exception) {
                _errorMessage.value = "Could not skip to next track."
            }
        }
    }

    override fun skipPrevious() {
        if (!_playerState.value.canSkipPrevious) return
        externalScope.launch {
            try {
                val response = withContext(Dispatchers.IO) { spotifyApi.skipToPrevious() }
                if (response.isSuccessful) {
                    delay(300)
                    syncPlaybackState()
                } else {
                    handlePlaybackApiError(response.code(), null)
                }
            } catch (_: Exception) {
                _errorMessage.value = "Could not skip to previous track."
            }
        }
    }

    override fun seekTo(positionMs: Long) {
        if (!_playerState.value.canSeek) return
        _playerState.value = _playerState.value.copy(playbackPositionMs = positionMs)
        externalScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    spotifyApi.seekToPosition(positionMs)
                }
            } catch (_: Exception) {
                // Ignore seek error
            }
        }
    }

    override fun setShuffle(enabled: Boolean) {
        _playerState.value = _playerState.value.copy(isShuffling = enabled)
        externalScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    spotifyApi.toggleShuffle(enabled)
                }
            } catch (_: Exception) {
                _errorMessage.value = "Could not change shuffle mode."
            }
        }
    }

    override fun setRepeat(mode: RepeatMode) {
        _playerState.value = _playerState.value.copy(repeatMode = mode)
        val stateString = when (mode) {
            RepeatMode.OFF -> "off"
            RepeatMode.CONTEXT -> "context"
            RepeatMode.TRACK -> "track"
        }
        externalScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    spotifyApi.setRepeatMode(stateString)
                }
            } catch (_: Exception) {
                _errorMessage.value = "Could not change repeat mode."
            }
        }
    }

    private fun handlePlaybackApiError(statusCode: Int, targetUri: String?) {
        when (statusCode) {
            403 -> {
                _errorMessage.value = "Spotify Premium is required for on-demand playback control."
            }
            404 -> {
                _errorMessage.value = "No active Spotify device found. Open Spotify to start playback."
                if (targetUri != null) {
                    IntentUtils.openSpotifyUri(context, targetUri)
                } else {
                    IntentUtils.openSpotifyApp(context)
                }
            }
            429 -> {
                _errorMessage.value = "Rate limit reached. Please wait a moment."
            }
            else -> {
                _errorMessage.value = "Open Spotify to continue playback."
                if (targetUri != null) {
                    IntentUtils.openSpotifyUri(context, targetUri)
                }
            }
        }
    }

    private fun startPolling() {
        stopPolling()
        pollingJob = externalScope.launch {
            while (isActive) {
                syncPlaybackState()
                delay(2500)
            }
        }
    }

    private fun stopPolling() {
        pollingJob?.cancel()
        pollingJob = null
        stopProgressTicker()
    }

    private suspend fun syncPlaybackState() = withContext(Dispatchers.IO) {
        try {
            val response = spotifyApi.getPlaybackState()
            if (response.isSuccessful && response.body() != null) {
                val dto = response.body()!!
                updatePlayerStateFromDto(dto)
            } else if (response.code() == 204) {
                // No active playback
                _playerState.value = _playerState.value.copy(
                    isPlaying = false,
                    deviceName = null
                )
                stopProgressTicker()
            }
        } catch (_: Exception) {
            // Transient network issues in polling should be quiet
        }
    }

    private fun updatePlayerStateFromDto(dto: com.example.core.network.PlaybackStateDto) {
        val trackDto = dto.item
        val trackModel = trackDto?.let {
            TrackModel(
                id = it.id,
                uri = it.uri,
                title = it.name,
                artist = it.artists.joinToString(", ") { a -> a.name },
                artistUri = it.artists.firstOrNull()?.uri,
                album = it.album?.name ?: "",
                albumArtUrl = it.album?.images?.firstOrNull()?.url,
                durationMs = it.durationMs,
                isPlayable = it.isPlayable ?: true
            )
        }

        val repeat = when (dto.repeatState.lowercase()) {
            "track" -> RepeatMode.TRACK
            "context" -> RepeatMode.CONTEXT
            else -> RepeatMode.OFF
        }

        val disallows = dto.actions?.disallows
        val canSkipNext = disallows?.skippingNext != true
        val canSkipPrev = disallows?.skippingPrev != true
        val canSeek = disallows?.seeking != true

        _playerState.value = PlayerStateModel(
            currentTrack = trackModel,
            isPlaying = dto.isPlaying,
            playbackPositionMs = dto.progressMs ?: 0L,
            durationMs = trackDto?.durationMs ?: 0L,
            isShuffling = dto.shuffleState,
            repeatMode = repeat,
            canSkipNext = canSkipNext,
            canSkipPrevious = canSkipPrev,
            canSeek = canSeek,
            deviceName = dto.device?.name,
            deviceType = dto.device?.type,
            playbackRestriction = if (!canSkipNext && !canSkipPrev && !dto.isPlaying) "Restricted by Spotify" else null,
            lastUpdatedTimestamp = System.currentTimeMillis()
        )

        if (dto.isPlaying) {
            startProgressTicker()
        } else {
            stopProgressTicker()
        }
    }

    private fun startProgressTicker() {
        if (progressTickerJob?.isActive == true) return
        progressTickerJob = externalScope.launch {
            while (isActive) {
                delay(1000)
                val current = _playerState.value
                if (current.isPlaying && current.durationMs > 0) {
                    val newPos = (current.playbackPositionMs + 1000L).coerceAtMost(current.durationMs)
                    _playerState.value = current.copy(playbackPositionMs = newPos)
                }
            }
        }
    }

    private fun stopProgressTicker() {
        progressTickerJob?.cancel()
        progressTickerJob = null
    }
}
