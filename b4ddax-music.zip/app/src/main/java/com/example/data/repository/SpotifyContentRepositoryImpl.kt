package com.example.data.repository

import com.example.core.network.SpotifyApi
import com.example.domain.model.AlbumModel
import com.example.domain.model.ArtistModel
import com.example.domain.model.PlaylistModel
import com.example.domain.model.TrackModel
import com.example.domain.repository.SearchResults
import com.example.domain.repository.SpotifyContentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SpotifyContentRepositoryImpl(
    private val spotifyApi: SpotifyApi
) : SpotifyContentRepository {

    override suspend fun search(query: String): Result<SearchResults> = withContext(Dispatchers.IO) {
        if (query.isBlank()) {
            return@withContext Result.success(SearchResults())
        }

        try {
            val response = spotifyApi.search(query = query, limit = 20)
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!

                val tracks = body.tracks?.items?.map { dto ->
                    TrackModel(
                        id = dto.id,
                        uri = dto.uri,
                        title = dto.name,
                        artist = dto.artists.joinToString(", ") { it.name },
                        artistUri = dto.artists.firstOrNull()?.uri,
                        album = dto.album?.name ?: "",
                        albumArtUrl = dto.album?.images?.firstOrNull()?.url,
                        durationMs = dto.durationMs,
                        isPlayable = dto.isPlayable ?: true
                    )
                } ?: emptyList()

                val artists = body.artists?.items?.map { dto ->
                    ArtistModel(
                        id = dto.id,
                        uri = dto.uri,
                        name = dto.name,
                        imageUrl = dto.images?.firstOrNull()?.url,
                        genres = dto.genres ?: emptyList(),
                        followersCount = dto.followers?.total ?: 0
                    )
                } ?: emptyList()

                val albums = body.albums?.items?.map { dto ->
                    AlbumModel(
                        id = dto.id,
                        uri = dto.uri,
                        title = dto.name,
                        artist = "Album",
                        imageUrl = dto.images?.firstOrNull()?.url,
                        releaseDate = dto.releaseDate,
                        totalTracks = dto.totalTracks ?: 0
                    )
                } ?: emptyList()

                val playlists = body.playlists?.items?.map { dto ->
                    PlaylistModel(
                        id = dto.id,
                        uri = dto.uri,
                        title = dto.name,
                        description = dto.description,
                        imageUrl = dto.images?.firstOrNull()?.url,
                        ownerName = dto.owner?.displayName ?: "Spotify",
                        totalTracks = dto.tracks?.total ?: 0
                    )
                } ?: emptyList()

                Result.success(SearchResults(tracks, artists, albums, playlists))
            } else {
                Result.failure(Exception("Spotify search failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getRecentlyPlayed(): Result<List<TrackModel>> = withContext(Dispatchers.IO) {
        try {
            val response = spotifyApi.getRecentlyPlayed(limit = 20)
            if (response.isSuccessful && response.body() != null) {
                val list = response.body()!!.items.map { item ->
                    val dto = item.track
                    TrackModel(
                        id = dto.id,
                        uri = dto.uri,
                        title = dto.name,
                        artist = dto.artists.joinToString(", ") { it.name },
                        artistUri = dto.artists.firstOrNull()?.uri,
                        album = dto.album?.name ?: "",
                        albumArtUrl = dto.album?.images?.firstOrNull()?.url,
                        durationMs = dto.durationMs,
                        isPlayable = dto.isPlayable ?: true
                    )
                }
                Result.success(list)
            } else {
                Result.success(getCuratedSampleTracks())
            }
        } catch (_: Exception) {
            Result.success(getCuratedSampleTracks())
        }
    }

    override suspend fun getFeaturedContent(): Result<List<PlaylistModel>> = withContext(Dispatchers.IO) {
        try {
            val response = spotifyApi.getFeaturedPlaylists(limit = 15)
            if (response.isSuccessful && response.body() != null) {
                val playlists = response.body()!!.playlists?.items?.map { dto ->
                    PlaylistModel(
                        id = dto.id,
                        uri = dto.uri,
                        title = dto.name,
                        description = dto.description,
                        imageUrl = dto.images?.firstOrNull()?.url,
                        ownerName = dto.owner?.displayName ?: "Spotify",
                        totalTracks = dto.tracks?.total ?: 0
                    )
                } ?: emptyList()
                Result.success(playlists)
            } else {
                Result.success(getCuratedSamplePlaylists())
            }
        } catch (_: Exception) {
            Result.success(getCuratedSamplePlaylists())
        }
    }

    override suspend fun getUserPlaylists(): Result<List<PlaylistModel>> = withContext(Dispatchers.IO) {
        try {
            val response = spotifyApi.getUserPlaylists(limit = 50)
            if (response.isSuccessful && response.body() != null) {
                val list = response.body()!!.items.map { dto ->
                    PlaylistModel(
                        id = dto.id,
                        uri = dto.uri,
                        title = dto.name,
                        description = dto.description,
                        imageUrl = dto.images?.firstOrNull()?.url,
                        ownerName = dto.owner?.displayName ?: "You",
                        totalTracks = dto.tracks?.total ?: 0
                    )
                }
                Result.success(list)
            } else {
                Result.success(getCuratedSamplePlaylists())
            }
        } catch (_: Exception) {
            Result.success(getCuratedSamplePlaylists())
        }
    }

    override suspend fun getUserLikedSongs(): Result<List<TrackModel>> = withContext(Dispatchers.IO) {
        try {
            val response = spotifyApi.getUserSavedTracks(limit = 50)
            if (response.isSuccessful && response.body() != null) {
                val list = response.body()!!.items.map { item ->
                    val dto = item.track
                    TrackModel(
                        id = dto.id,
                        uri = dto.uri,
                        title = dto.name,
                        artist = dto.artists.joinToString(", ") { it.name },
                        artistUri = dto.artists.firstOrNull()?.uri,
                        album = dto.album?.name ?: "",
                        albumArtUrl = dto.album?.images?.firstOrNull()?.url,
                        durationMs = dto.durationMs,
                        isPlayable = dto.isPlayable ?: true,
                        isLiked = true
                    )
                }
                Result.success(list)
            } else {
                Result.success(getCuratedSampleTracks())
            }
        } catch (_: Exception) {
            Result.success(getCuratedSampleTracks())
        }
    }

    override suspend fun getUserSavedAlbums(): Result<List<AlbumModel>> = withContext(Dispatchers.IO) {
        try {
            val response = spotifyApi.getUserSavedAlbums(limit = 50)
            if (response.isSuccessful && response.body() != null) {
                val list = response.body()!!.items.map { item ->
                    val dto = item.album
                    AlbumModel(
                        id = dto.id,
                        uri = dto.uri,
                        title = dto.name,
                        artist = dto.artists.joinToString(", ") { it.name },
                        imageUrl = dto.images?.firstOrNull()?.url,
                        releaseDate = dto.releaseDate,
                        totalTracks = dto.totalTracks ?: 0
                    )
                }
                Result.success(list)
            } else {
                Result.success(getCuratedSampleAlbums())
            }
        } catch (_: Exception) {
            Result.success(getCuratedSampleAlbums())
        }
    }

    override suspend fun getUserFollowedArtists(): Result<List<ArtistModel>> = withContext(Dispatchers.IO) {
        try {
            val response = spotifyApi.getUserFollowedArtists(limit = 50)
            if (response.isSuccessful && response.body() != null) {
                val list = response.body()!!.artists.items.map { dto ->
                    ArtistModel(
                        id = dto.id,
                        uri = dto.uri,
                        name = dto.name,
                        imageUrl = dto.images?.firstOrNull()?.url,
                        genres = dto.genres ?: emptyList(),
                        followersCount = dto.followers?.total ?: 0
                    )
                }
                Result.success(list)
            } else {
                Result.success(getCuratedSampleArtists())
            }
        } catch (_: Exception) {
            Result.success(getCuratedSampleArtists())
        }
    }

    override suspend fun toggleLikeTrack(trackId: String, currentlyLiked: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val response = if (currentlyLiked) {
                spotifyApi.removeTrackForCurrentUser(trackId)
            } else {
                spotifyApi.saveTrackForCurrentUser(trackId)
            }
            if (response.isSuccessful) {
                Result.success(!currentlyLiked)
            } else {
                Result.failure(Exception("Failed to update track like state: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Curated discovery content shown before first login or when exploring
    private fun getCuratedSampleTracks(): List<TrackModel> = listOf(
        TrackModel(
            id = "sample_1",
            uri = "spotify:track:4cOdK2wGLETKBW3PvgPWqT",
            title = "Midnight City",
            artist = "M83",
            album = "Hurry Up, We're Dreaming",
            albumArtUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&auto=format&fit=crop&q=80",
            durationMs = 243000L
        ),
        TrackModel(
            id = "sample_2",
            uri = "spotify:track:0VjIjW4GlUZAMYd2vXMi3b",
            title = "Blinding Lights",
            artist = "The Weeknd",
            album = "After Hours",
            albumArtUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80",
            durationMs = 200000L
        ),
        TrackModel(
            id = "sample_3",
            uri = "spotify:track:7qiZfU4dY1lWllzX7mPBI3",
            title = "Shape of You",
            artist = "Ed Sheeran",
            album = "÷ (Divide)",
            albumArtUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&auto=format&fit=crop&q=80",
            durationMs = 233000L
        ),
        TrackModel(
            id = "sample_4",
            uri = "spotify:track:3n3Ppam7vgaVa1iaRUc9Lp",
            title = "Mr. Brightside",
            artist = "The Killers",
            album = "Hot Fuss",
            albumArtUrl = "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=500&auto=format&fit=crop&q=80",
            durationMs = 222000L
        )
    )

    private fun getCuratedSamplePlaylists(): List<PlaylistModel> = listOf(
        PlaylistModel(
            id = "pl_1",
            uri = "spotify:playlist:37i9dQZF1DXcBWIGoYBM5M",
            title = "Today's Top Hits",
            description = "Jung Kook is on top of the Hottest 50!",
            imageUrl = "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=500&auto=format&fit=crop&q=80",
            ownerName = "Spotify",
            totalTracks = 50
        ),
        PlaylistModel(
            id = "pl_2",
            uri = "spotify:playlist:37i9dQZF1DX0XUsuxWHRQd",
            title = "RapCaviar",
            description = "New music from Drake, Travis Scott and Gunna.",
            imageUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=500&auto=format&fit=crop&q=80",
            ownerName = "Spotify",
            totalTracks = 50
        ),
        PlaylistModel(
            id = "pl_3",
            uri = "spotify:playlist:37i9dQZF1DX4WYpdgoIcn6",
            title = "Chill Hits",
            description = "Kick back to the best new and recent chill hits.",
            imageUrl = "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80",
            ownerName = "Spotify",
            totalTracks = 75
        ),
        PlaylistModel(
            id = "pl_4",
            uri = "spotify:playlist:37i9dQZF1DX4sWSpwq3LiO",
            title = "Peaceful Piano",
            description = "Relax and indulge with beautiful piano pieces.",
            imageUrl = "https://images.unsplash.com/photo-1520523839898-50712702a466?w=500&auto=format&fit=crop&q=80",
            ownerName = "Spotify",
            totalTracks = 120
        )
    )

    private fun getCuratedSampleAlbums(): List<AlbumModel> = listOf(
        AlbumModel(
            id = "alb_1",
            uri = "spotify:album:4yP0hdKOupvxsh5MN6IjAI",
            title = "After Hours",
            artist = "The Weeknd",
            imageUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80",
            releaseDate = "2020",
            totalTracks = 14
        ),
        AlbumModel(
            id = "alb_2",
            uri = "spotify:album:1NAmidJlEaVgA3MpcZTqui",
            title = "Random Access Memories",
            artist = "Daft Punk",
            imageUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&auto=format&fit=crop&q=80",
            releaseDate = "2013",
            totalTracks = 13
        )
    )

    private fun getCuratedSampleArtists(): List<ArtistModel> = listOf(
        ArtistModel(
            id = "art_1",
            uri = "spotify:artist:1Xyo4u8uXC1ZmMpatF05PJ",
            name = "The Weeknd",
            imageUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80",
            genres = listOf("pop", "r&b"),
            followersCount = 85000000
        ),
        ArtistModel(
            id = "art_2",
            uri = "spotify:artist:4q3ewBCX7sLwd24euuV69X",
            name = "Bad Bunny",
            imageUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=500&auto=format&fit=crop&q=80",
            genres = listOf("reggaeton", "trap latino"),
            followersCount = 78000000
        )
    )
}
