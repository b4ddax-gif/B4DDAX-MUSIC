package com.example.data.repository

import android.net.Uri
import com.example.BuildConfig
import com.example.core.config.SpotifyConfig
import com.example.core.network.SpotifyApi
import com.example.core.security.PkceUtil
import com.example.core.security.TokenStorage
import com.example.domain.model.UserProfileModel
import com.example.domain.repository.SpotifyAuthRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SpotifyAuthRepositoryImpl(
    private val spotifyApi: SpotifyApi,
    private val tokenStorage: TokenStorage,
    private val externalScope: CoroutineScope
) : SpotifyAuthRepository {

    private val _clientId = MutableStateFlow(resolveInitialClientId())
    override val clientId: StateFlow<String> = _clientId.asStateFlow()

    private val _redirectUri = MutableStateFlow(resolveInitialRedirectUri())
    override val redirectUri: StateFlow<String> = _redirectUri.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(tokenStorage.getAccessToken() != null)
    override val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _currentUserProfile = MutableStateFlow<UserProfileModel?>(null)
    override val currentUserProfile: StateFlow<UserProfileModel?> = _currentUserProfile.asStateFlow()

    init {
        if (_isAuthenticated.value) {
            externalScope.launch {
                fetchCurrentUserProfile()
            }
        }
    }

    private fun resolveInitialClientId(): String {
        val custom = tokenStorage.getCustomClientId()
        if (!custom.isNullOrBlank()) return custom

        return try {
            val buildConfigKey = BuildConfig::class.java.getField("SPOTIFY_CLIENT_ID").get(null) as? String
            if (!buildConfigKey.isNullOrBlank() && buildConfigKey != "YOUR_SPOTIFY_CLIENT_ID") {
                buildConfigKey
            } else {
                "YOUR_SPOTIFY_CLIENT_ID"
            }
        } catch (_: Exception) {
            "YOUR_SPOTIFY_CLIENT_ID"
        }
    }

    private fun resolveInitialRedirectUri(): String {
        val custom = tokenStorage.getCustomRedirectUri()
        if (!custom.isNullOrBlank()) return custom

        return try {
            val buildConfigUri = BuildConfig::class.java.getField("SPOTIFY_REDIRECT_URI").get(null) as? String
            if (!buildConfigUri.isNullOrBlank()) {
                buildConfigUri
            } else {
                SpotifyConfig.DEFAULT_REDIRECT_URI
            }
        } catch (_: Exception) {
            SpotifyConfig.DEFAULT_REDIRECT_URI
        }
    }

    override fun getAuthorizationUrl(): String {
        val verifier = PkceUtil.generateCodeVerifier()
        tokenStorage.saveCodeVerifier(verifier)
        val challenge = PkceUtil.generateCodeChallenge(verifier)

        val uriBuilder = Uri.parse(SpotifyConfig.SPOTIFY_AUTH_ENDPOINT).buildUpon()
            .appendQueryParameter("client_id", _clientId.value)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("redirect_uri", _redirectUri.value)
            .appendQueryParameter("code_challenge_method", "S256")
            .appendQueryParameter("code_challenge", challenge)
            .appendQueryParameter("scope", SpotifyConfig.SCOPES_QUERY)
            .appendQueryParameter("show_dialog", "true")

        return uriBuilder.build().toString()
    }

    override suspend fun handleAuthCallbackUri(uriString: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val uri = Uri.parse(uriString)
            val error = uri.getQueryParameter("error")
            if (!error.isNullOrBlank()) {
                return@withContext Result.failure(Exception("Spotify authorization error: $error"))
            }

            val code = uri.getQueryParameter("code")
                ?: return@withContext Result.failure(Exception("No authorization code received in callback"))

            val verifier = tokenStorage.getAndClearCodeVerifier()
                ?: return@withContext Result.failure(Exception("Missing PKCE code verifier"))

            val response = spotifyApi.exchangeCodeForToken(
                code = code,
                redirectUri = _redirectUri.value,
                clientId = _clientId.value,
                codeVerifier = verifier
            )

            if (response.isSuccessful && response.body() != null) {
                val tokenBody = response.body()!!
                tokenStorage.saveTokens(
                    accessToken = tokenBody.accessToken,
                    refreshToken = tokenBody.refreshToken,
                    expiresInSeconds = tokenBody.expiresIn
                )
                _isAuthenticated.value = true
                fetchCurrentUserProfile()
                Result.success(true)
            } else {
                val errorMsg = response.errorBody()?.string() ?: "Failed to exchange authorization code: ${response.code()}"
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun refreshAccessToken(): Result<String> = withContext(Dispatchers.IO) {
        val refreshToken = tokenStorage.getRefreshToken()
            ?: return@withContext Result.failure(Exception("No refresh token available"))

        try {
            val response = spotifyApi.refreshAccessToken(
                refreshToken = refreshToken,
                clientId = _clientId.value
            )
            if (response.isSuccessful && response.body() != null) {
                val tokenBody = response.body()!!
                tokenStorage.saveTokens(
                    accessToken = tokenBody.accessToken,
                    refreshToken = tokenBody.refreshToken ?: refreshToken,
                    expiresInSeconds = tokenBody.expiresIn
                )
                _isAuthenticated.value = true
                Result.success(tokenBody.accessToken)
            } else {
                Result.failure(Exception("Failed to refresh token: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun fetchCurrentUserProfile(): Result<UserProfileModel> = withContext(Dispatchers.IO) {
        try {
            val response = spotifyApi.getCurrentUserProfile()
            if (response.isSuccessful && response.body() != null) {
                val dto = response.body()!!
                val profile = UserProfileModel(
                    id = dto.id,
                    displayName = dto.displayName ?: dto.id,
                    email = dto.email,
                    product = dto.product,
                    profileImageUrl = dto.images?.firstOrNull()?.url,
                    followersCount = dto.followers?.total ?: 0,
                    country = dto.country
                )
                _currentUserProfile.value = profile
                Result.success(profile)
            } else {
                Result.failure(Exception("Failed to fetch user profile: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun logout() {
        tokenStorage.clearAll()
        _isAuthenticated.value = false
        _currentUserProfile.value = null
    }

    override fun updateCredentials(clientId: String, redirectUri: String) {
        _clientId.value = clientId.trim()
        _redirectUri.value = redirectUri.trim()
        tokenStorage.saveCustomCredentials(clientId.trim(), redirectUri.trim())
    }

    override fun getAccessToken(): String? = tokenStorage.getAccessToken()
}
