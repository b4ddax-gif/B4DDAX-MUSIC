package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// B4DDAX Music Brand Palette
val B4ddaxBlack = Color(0xFF090909)
val B4ddaxSurface = Color(0xFF151515)
val B4ddaxSurfaceVariant = Color(0xFF202020)
val B4ddaxSurfaceElevated = Color(0xFF282828)
val B4ddaxBorder = Color(0xFF2C2C2E)

val B4ddaxGreenPrimary = Color(0xFF1DB954)
val B4ddaxGreenAccent = Color(0xFF1ED760)
val B4ddaxGreenGlow = Color(0x331ED760)

val B4ddaxTextPrimary = Color(0xFFFFFFFF)
val B4ddaxTextSecondary = Color(0xFFB3B3B3)
val B4ddaxTextMuted = Color(0xFF71717A)

val B4ddaxRed = Color(0xFFEF4444)
val B4ddaxWarning = Color(0xFFF59E0B)
val B4ddaxCardGradientStart = Color(0xFF1F1F1F)
val B4ddaxCardGradientEnd = Color(0xFF141414)
