package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val B4ddaxDarkColorScheme = darkColorScheme(
    primary = B4ddaxGreenPrimary,
    onPrimary = B4ddaxBlack,
    primaryContainer = B4ddaxSurfaceVariant,
    onPrimaryContainer = B4ddaxGreenAccent,
    secondary = B4ddaxGreenAccent,
    onSecondary = B4ddaxBlack,
    secondaryContainer = B4ddaxSurfaceElevated,
    onSecondaryContainer = B4ddaxTextPrimary,
    tertiary = B4ddaxGreenAccent,
    onTertiary = B4ddaxBlack,
    background = B4ddaxBlack,
    onBackground = B4ddaxTextPrimary,
    surface = B4ddaxSurface,
    onSurface = B4ddaxTextPrimary,
    surfaceVariant = B4ddaxSurfaceVariant,
    onSurfaceVariant = B4ddaxTextSecondary,
    outline = B4ddaxBorder,
    outlineVariant = B4ddaxSurfaceElevated,
    error = B4ddaxRed,
    onError = B4ddaxTextPrimary
)

@Composable
fun B4ddaxMusicTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = B4ddaxBlack.toArgb()
                window.navigationBarColor = B4ddaxBlack.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = B4ddaxDarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    B4ddaxMusicTheme(content = content)
}
