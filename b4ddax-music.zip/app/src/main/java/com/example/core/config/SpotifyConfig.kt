package com.example.core.config

object SpotifyConfig {
    const val DEFAULT_REDIRECT_URI = "b4ddax://callback"
    const val SPOTIFY_AUTH_ENDPOINT = "https://accounts.spotify.com/authorize"
    const val SPOTIFY_TOKEN_ENDPOINT = "https://accounts.spotify.com/api/token"
    const val SPOTIFY_API_BASE_URL = "https://api.spotify.com/v1/"
    const val SPOTIFY_PACKAGE_NAME = "com.spotify.music"

    // Only minimum scopes required as per Spotify specifications
    val REQUIRED_SCOPES = listOf(
        "app-remote-control",
        "user-read-currently-playing",
        "user-read-playback-state",
        "user-modify-playback-state",
        "playlist-read-private",
        "playlist-read-collaborative",
        "user-library-read",
        "user-read-recently-played"
    )

    val SCOPES_QUERY: String = REQUIRED_SCOPES.joinToString(" ")
}
