package com.example.core.utils

import java.util.Locale
import java.util.concurrent.TimeUnit

object TimeUtils {

    fun formatDurationMs(durationMs: Long): String {
        if (durationMs <= 0L) return "0:00"
        val minutes = TimeUnit.MILLISECONDS.toMinutes(durationMs)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(durationMs) % 60
        return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
    }

    fun getTimeBasedGreeting(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 4..11 -> "Good morning"
            in 12..17 -> "Good afternoon"
            else -> "Good evening"
        }
    }
}
