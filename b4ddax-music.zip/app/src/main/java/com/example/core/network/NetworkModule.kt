package com.example.core.network

import com.example.core.config.SpotifyConfig
import com.example.core.security.TokenStorage
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object NetworkModule {

    fun provideMoshi(): Moshi {
        return Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
    }

    fun provideOkHttpClient(
        tokenStorage: TokenStorage,
        getClientId: () -> String
    ): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            // Never log sensitive Authorization headers in release/debug
            level = HttpLoggingInterceptor.Level.BASIC
        }

        return OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(SpotifyAuthInterceptor(tokenStorage, getClientId))
            .addInterceptor(logging)
            .build()
    }

    fun provideSpotifyApi(okHttpClient: OkHttpClient, moshi: Moshi): SpotifyApi {
        return Retrofit.Builder()
            .baseUrl(SpotifyConfig.SPOTIFY_API_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(SpotifyApi::class.java)
    }
}
