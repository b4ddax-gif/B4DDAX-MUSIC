package com.example.core.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Query

interface SpotifyApi {

    @FormUrlEncoded
    @POST("https://accounts.spotify.com/api/token")
    suspend fun exchangeCodeForToken(
        @Field("grant_type") grantType: String = "authorization_code",
        @Field("code") code: String,
        @Field("redirect_uri") redirectUri: String,
        @Field("client_id") clientId: String,
        @Field("code_verifier") codeVerifier: String
    ): Response<TokenResponseDto>

    @FormUrlEncoded
    @POST("https://accounts.spotify.com/api/token")
    suspend fun refreshAccessToken(
        @Field("grant_type") grantType: String = "refresh_token",
        @Field("refresh_token") refreshToken: String,
        @Field("client_id") clientId: String
    ): Response<TokenResponseDto>

    @GET("me")
    suspend fun getCurrentUserProfile(): Response<SpotifyUserDto>

    @GET("me/player")
    suspend fun getPlaybackState(): Response<PlaybackStateDto>

    @PUT("me/player/play")
    suspend fun startPlayback(
        @Body body: PlayRequestBody? = null
    ): Response<Unit>

    @PUT("me/player/pause")
    suspend fun pausePlayback(): Response<Unit>

    @POST("me/player/next")
    suspend fun skipToNext(): Response<Unit>

    @POST("me/player/previous")
    suspend fun skipToPrevious(): Response<Unit>

    @PUT("me/player/seek")
    suspend fun seekToPosition(
        @Query("position_ms") positionMs: Long
    ): Response<Unit>

    @PUT("me/player/shuffle")
    suspend fun toggleShuffle(
        @Query("state") state: Boolean
    ): Response<Unit>

    @PUT("me/player/repeat")
    suspend fun setRepeatMode(
        @Query("state") state: String // "off", "track", "context"
    ): Response<Unit>

    @GET("search")
    suspend fun search(
        @Query("q") query: String,
        @Query("type") type: String = "track,artist,album,playlist",
        @Query("limit") limit: Int = 20
    ): Response<SpotifySearchResponseDto>

    @GET("me/player/recently-played")
    suspend fun getRecentlyPlayed(
        @Query("limit") limit: Int = 20
    ): Response<RecentlyPlayedResponseDto>

    @GET("browse/featured-playlists")
    suspend fun getFeaturedPlaylists(
        @Query("limit") limit: Int = 20
    ): Response<SpotifySearchResponseDto>

    @GET("me/playlists")
    suspend fun getUserPlaylists(
        @Query("limit") limit: Int = 50
    ): Response<SpotifyPagingDto<SpotifyPlaylistDto>>

    @GET("me/tracks")
    suspend fun getUserSavedTracks(
        @Query("limit") limit: Int = 50
    ): Response<SpotifyPagingDto<SavedTrackItemDto>>

    @GET("me/albums")
    suspend fun getUserSavedAlbums(
        @Query("limit") limit: Int = 50
    ): Response<SpotifyPagingDto<SavedAlbumItemDto>>

    @GET("me/following")
    suspend fun getUserFollowedArtists(
        @Query("type") type: String = "artist",
        @Query("limit") limit: Int = 50
    ): Response<FollowedArtistsResponseDto>

    @PUT("me/tracks")
    suspend fun saveTrackForCurrentUser(
        @Query("ids") trackIds: String
    ): Response<Unit>

    @retrofit2.http.DELETE("me/tracks")
    suspend fun removeTrackForCurrentUser(
        @Query("ids") trackIds: String
    ): Response<Unit>
}
