package com.example.core.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class TokenResponseDto(
    @Json(name = "access_token") val accessToken: String,
    @Json(name = "token_type") val tokenType: String,
    @Json(name = "scope") val scope: String? = null,
    @Json(name = "expires_in") val expiresIn: Long,
    @Json(name = "refresh_token") val refreshToken: String? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyUserDto(
    @Json(name = "id") val id: String,
    @Json(name = "display_name") val displayName: String?,
    @Json(name = "email") val email: String? = null,
    @Json(name = "product") val product: String? = null, // "premium", "free", "open"
    @Json(name = "country") val country: String? = null,
    @Json(name = "images") val images: List<SpotifyImageDto>? = null,
    @Json(name = "followers") val followers: SpotifyFollowersDto? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyImageDto(
    @Json(name = "url") val url: String,
    @Json(name = "height") val height: Int? = null,
    @Json(name = "width") val width: Int? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyFollowersDto(
    @Json(name = "total") val total: Int = 0
)

@JsonClass(generateAdapter = true)
data class PlaybackStateDto(
    @Json(name = "is_playing") val isPlaying: Boolean = false,
    @Json(name = "progress_ms") val progressMs: Long? = 0L,
    @Json(name = "item") val item: SpotifyTrackDto? = null,
    @Json(name = "device") val device: SpotifyDeviceDto? = null,
    @Json(name = "shuffle_state") val shuffleState: Boolean = false,
    @Json(name = "repeat_state") val repeatState: String = "off", // "off", "track", "context"
    @Json(name = "actions") val actions: SpotifyActionsDto? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyDeviceDto(
    @Json(name = "id") val id: String?,
    @Json(name = "name") val name: String?,
    @Json(name = "type") val type: String?,
    @Json(name = "is_active") val isActive: Boolean = false,
    @Json(name = "volume_percent") val volumePercent: Int? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyActionsDto(
    @Json(name = "disallows") val disallows: SpotifyDisallowsDto? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyDisallowsDto(
    @Json(name = "pausing") val pausing: Boolean? = null,
    @Json(name = "resuming") val resuming: Boolean? = null,
    @Json(name = "skipping_next") val skippingNext: Boolean? = null,
    @Json(name = "skipping_prev") val skippingPrev: Boolean? = null,
    @Json(name = "seeking") val seeking: Boolean? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyTrackDto(
    @Json(name = "id") val id: String,
    @Json(name = "uri") val uri: String,
    @Json(name = "name") val name: String,
    @Json(name = "artists") val artists: List<SpotifyArtistSimpleDto> = emptyList(),
    @Json(name = "album") val album: SpotifyAlbumSimpleDto? = null,
    @Json(name = "duration_ms") val durationMs: Long = 0L,
    @Json(name = "is_playable") val isPlayable: Boolean? = true
)

@JsonClass(generateAdapter = true)
data class SpotifyArtistSimpleDto(
    @Json(name = "id") val id: String,
    @Json(name = "uri") val uri: String,
    @Json(name = "name") val name: String
)

@JsonClass(generateAdapter = true)
data class SpotifyArtistDto(
    @Json(name = "id") val id: String,
    @Json(name = "uri") val uri: String,
    @Json(name = "name") val name: String,
    @Json(name = "images") val images: List<SpotifyImageDto>? = null,
    @Json(name = "genres") val genres: List<String>? = null,
    @Json(name = "followers") val followers: SpotifyFollowersDto? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyAlbumSimpleDto(
    @Json(name = "id") val id: String,
    @Json(name = "uri") val uri: String,
    @Json(name = "name") val name: String,
    @Json(name = "images") val images: List<SpotifyImageDto>? = null,
    @Json(name = "release_date") val releaseDate: String? = null,
    @Json(name = "total_tracks") val totalTracks: Int? = 0
)

@JsonClass(generateAdapter = true)
data class SpotifyAlbumDto(
    @Json(name = "id") val id: String,
    @Json(name = "uri") val uri: String,
    @Json(name = "name") val name: String,
    @Json(name = "artists") val artists: List<SpotifyArtistSimpleDto> = emptyList(),
    @Json(name = "images") val images: List<SpotifyImageDto>? = null,
    @Json(name = "release_date") val releaseDate: String? = null,
    @Json(name = "total_tracks") val totalTracks: Int? = 0
)

@JsonClass(generateAdapter = true)
data class SpotifyPlaylistDto(
    @Json(name = "id") val id: String,
    @Json(name = "uri") val uri: String,
    @Json(name = "name") val name: String,
    @Json(name = "description") val description: String? = null,
    @Json(name = "images") val images: List<SpotifyImageDto>? = null,
    @Json(name = "owner") val owner: SpotifyUserSimpleDto? = null,
    @Json(name = "tracks") val tracks: SpotifyTracksRefDto? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyUserSimpleDto(
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "id") val id: String? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyTracksRefDto(
    @Json(name = "total") val total: Int = 0
)

@JsonClass(generateAdapter = true)
data class SpotifySearchResponseDto(
    @Json(name = "tracks") val tracks: SpotifyPagingDto<SpotifyTrackDto>? = null,
    @Json(name = "artists") val artists: SpotifyPagingDto<SpotifyArtistDto>? = null,
    @Json(name = "albums") val albums: SpotifyPagingDto<SpotifyAlbumSimpleDto>? = null,
    @Json(name = "playlists") val playlists: SpotifyPagingDto<SpotifyPlaylistDto>? = null
)

@JsonClass(generateAdapter = true)
data class SpotifyPagingDto<T>(
    @Json(name = "items") val items: List<T> = emptyList(),
    @Json(name = "total") val total: Int = 0,
    @Json(name = "limit") val limit: Int = 20,
    @Json(name = "offset") val offset: Int = 0
)

@JsonClass(generateAdapter = true)
data class RecentlyPlayedResponseDto(
    @Json(name = "items") val items: List<RecentlyPlayedItemDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class RecentlyPlayedItemDto(
    @Json(name = "track") val track: SpotifyTrackDto,
    @Json(name = "played_at") val playedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class SavedTrackItemDto(
    @Json(name = "added_at") val addedAt: String? = null,
    @Json(name = "track") val track: SpotifyTrackDto
)

@JsonClass(generateAdapter = true)
data class SavedAlbumItemDto(
    @Json(name = "added_at") val addedAt: String? = null,
    @Json(name = "album") val album: SpotifyAlbumDto
)

@JsonClass(generateAdapter = true)
data class FollowedArtistsResponseDto(
    @Json(name = "artists") val artists: SpotifyPagingDto<SpotifyArtistDto>
)

@JsonClass(generateAdapter = true)
data class PlayRequestBody(
    @Json(name = "uris") val uris: List<String>? = null,
    @Json(name = "context_uri") val contextUri: String? = null,
    @Json(name = "position_ms") val positionMs: Long? = null
)
