package com.example.core.network

import com.example.core.config.SpotifyConfig
import com.example.core.security.TokenStorage
import okhttp3.FormBody
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject

class SpotifyAuthInterceptor(
    private val tokenStorage: TokenStorage,
    private val getClientId: () -> String
) : Interceptor {

    private val refreshHttpClient = OkHttpClient()

    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val url = originalRequest.url.toString()

        // Only attach Spotify Bearer tokens to Spotify Web API calls
        if (!url.startsWith(SpotifyConfig.SPOTIFY_API_BASE_URL)) {
            return chain.proceed(originalRequest)
        }

        var accessToken = tokenStorage.getAccessToken()

        // Check if token needs refresh
        if (tokenStorage.isAccessTokenExpired() && tokenStorage.getRefreshToken() != null) {
            val refreshed = refreshAccessTokenSync()
            if (refreshed != null) {
                accessToken = refreshed
            }
        }

        if (accessToken == null) {
            return chain.proceed(originalRequest)
        }

        val authenticatedRequest = originalRequest.newBuilder()
            .header("Authorization", "Bearer $accessToken")
            .build()

        val response = chain.proceed(authenticatedRequest)

        // Handle 401 Unauthorized (token revoked or expired mid-session)
        if (response.code == 401 && tokenStorage.getRefreshToken() != null) {
            response.close()
            val newAccessToken = refreshAccessTokenSync()
            if (newAccessToken != null) {
                val retryRequest = originalRequest.newBuilder()
                    .header("Authorization", "Bearer $newAccessToken")
                    .build()
                return chain.proceed(retryRequest)
            }
        }

        return response
    }

    @Synchronized
    private fun refreshAccessTokenSync(): String? {
        val refreshToken = tokenStorage.getRefreshToken() ?: return null
        val clientId = getClientId()
        if (clientId.isBlank() || clientId == "YOUR_SPOTIFY_CLIENT_ID") {
            return null
        }

        return try {
            val body = FormBody.Builder()
                .add("grant_type", "refresh_token")
                .add("refresh_token", refreshToken)
                .add("client_id", clientId)
                .build()

            val request = Request.Builder()
                .url(SpotifyConfig.SPOTIFY_TOKEN_ENDPOINT)
                .post(body)
                .build()

            val response = refreshHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val jsonString = response.body?.string() ?: return null
                val json = JSONObject(jsonString)
                val newAccessToken = json.getString("access_token")
                val expiresIn = json.optLong("expires_in", 3600L)
                val newRefreshToken = json.optString("refresh_token", null)

                tokenStorage.saveTokens(
                    accessToken = newAccessToken,
                    refreshToken = if (newRefreshToken.isNullOrEmpty()) refreshToken else newRefreshToken,
                    expiresInSeconds = expiresIn
                )
                newAccessToken
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }
}
