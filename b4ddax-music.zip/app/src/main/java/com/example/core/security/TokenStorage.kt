package com.example.core.security

import android.content.Context
import android.content.SharedPreferences

class TokenStorage(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    fun saveTokens(
        accessToken: String,
        refreshToken: String?,
        expiresInSeconds: Long
    ) {
        val expiryTimeMillis = System.currentTimeMillis() + (expiresInSeconds * 1000L)
        prefs.edit().apply {
            putString(KEY_ACCESS_TOKEN, accessToken)
            if (!refreshToken.isNullOrBlank()) {
                putString(KEY_REFRESH_TOKEN, refreshToken)
            }
            putLong(KEY_EXPIRY_TIME_MILLIS, expiryTimeMillis)
            apply()
        }
    }

    fun getAccessToken(): String? {
        val token = prefs.getString(KEY_ACCESS_TOKEN, null)
        return if (!token.isNullOrBlank()) token else null
    }

    fun getRefreshToken(): String? {
        val token = prefs.getString(KEY_REFRESH_TOKEN, null)
        return if (!token.isNullOrBlank()) token else null
    }

    fun isAccessTokenExpired(): Boolean {
        val expiry = prefs.getLong(KEY_EXPIRY_TIME_MILLIS, 0L)
        // Buffer of 60 seconds before actual expiration
        return System.currentTimeMillis() >= (expiry - 60_000L)
    }

    fun saveCodeVerifier(verifier: String) {
        prefs.edit().putString(KEY_CODE_VERIFIER, verifier).apply()
    }

    fun getAndClearCodeVerifier(): String? {
        val verifier = prefs.getString(KEY_CODE_VERIFIER, null)
        prefs.edit().remove(KEY_CODE_VERIFIER).apply()
        return verifier
    }

    fun saveCustomCredentials(clientId: String?, redirectUri: String?) {
        prefs.edit().apply {
            if (clientId != null) putString(KEY_CUSTOM_CLIENT_ID, clientId)
            if (redirectUri != null) putString(KEY_CUSTOM_REDIRECT_URI, redirectUri)
            apply()
        }
    }

    fun getCustomClientId(): String? = prefs.getString(KEY_CUSTOM_CLIENT_ID, null)

    fun getCustomRedirectUri(): String? = prefs.getString(KEY_CUSTOM_REDIRECT_URI, null)

    fun clearAll() {
        prefs.edit()
            .remove(KEY_ACCESS_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_EXPIRY_TIME_MILLIS)
            .remove(KEY_CODE_VERIFIER)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "b4ddax_secure_tokens"
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_EXPIRY_TIME_MILLIS = "expiry_time_millis"
        private const val KEY_CODE_VERIFIER = "pkce_code_verifier"
        private const val KEY_CUSTOM_CLIENT_ID = "custom_client_id"
        private const val KEY_CUSTOM_REDIRECT_URI = "custom_redirect_uri"
    }
}
