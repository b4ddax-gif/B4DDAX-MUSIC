package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import com.example.presentation.navigation.B4ddaxMainScreen
import com.example.ui.theme.B4ddaxMusicTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val app: B4ddaxApplication
        get() = application as B4ddaxApplication

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleOAuthIntent(intent)

        setContent {
            B4ddaxMusicTheme {
                B4ddaxMainScreen(app = app)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleOAuthIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        // Automatically connect or sync player state when returning to foreground
        if (app.authRepository.isAuthenticated.value) {
            app.playerController.connect()
        }
    }

    override fun onResume() {
        super.onResume()
        // Subscribe to player state updates
        app.playerController.subscribeToPlayerState()
    }

    override fun onStop() {
        super.onStop()
        // Gracefully keep background sync minimal
    }

    override fun onDestroy() {
        super.onDestroy()
        // Disconnect safely when activity is being finished
        if (isFinishing) {
            app.playerController.disconnect()
        }
    }

    private fun handleOAuthIntent(intent: Intent?) {
        val uri: Uri = intent?.data ?: return
        if (uri.scheme.equals("b4ddax", ignoreCase = true) && uri.host.equals("callback", ignoreCase = true)) {
            lifecycleScope.launch {
                val result = app.authRepository.handleAuthCallbackUri(uri.toString())
                if (result.isSuccess) {
                    Toast.makeText(this@MainActivity, "Connected to Spotify!", Toast.LENGTH_SHORT).show()
                    app.playerController.connect()
                } else {
                    val errorMsg = result.exceptionOrNull()?.message ?: "Authorization failed"
                    Toast.makeText(this@MainActivity, errorMsg, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
