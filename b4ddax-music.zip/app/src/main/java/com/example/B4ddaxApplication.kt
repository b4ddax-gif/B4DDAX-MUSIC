package com.example

import android.app.Application
import com.example.core.network.NetworkModule
import com.example.core.security.TokenStorage
import com.example.data.local.PreferencesDataStore
import com.example.data.repository.SpotifyAuthRepositoryImpl
import com.example.data.repository.SpotifyContentRepositoryImpl
import com.example.data.repository.SpotifyPlayerRepositoryImpl
import com.example.domain.repository.SpotifyAuthRepository
import com.example.domain.repository.SpotifyContentRepository
import com.example.domain.repository.SpotifyPlayerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class B4ddaxApplication : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    lateinit var tokenStorage: TokenStorage
        private set

    lateinit var preferencesDataStore: PreferencesDataStore
        private set

    lateinit var authRepository: SpotifyAuthRepository
        private set

    lateinit var playerController: SpotifyPlayerController
        private set

    lateinit var contentRepository: SpotifyContentRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        tokenStorage = TokenStorage(this)
        preferencesDataStore = PreferencesDataStore(this)

        val moshi = NetworkModule.provideMoshi()
        val okHttpClient = NetworkModule.provideOkHttpClient(
            tokenStorage = tokenStorage,
            getClientId = {
                (authRepository as? SpotifyAuthRepositoryImpl)?.clientId?.value
                    ?: tokenStorage.getCustomClientId()
                    ?: "YOUR_SPOTIFY_CLIENT_ID"
            }
        )
        val spotifyApi = NetworkModule.provideSpotifyApi(okHttpClient, moshi)

        authRepository = SpotifyAuthRepositoryImpl(
            spotifyApi = spotifyApi,
            tokenStorage = tokenStorage,
            externalScope = applicationScope
        )

        playerController = SpotifyPlayerRepositoryImpl(
            context = this,
            spotifyApi = spotifyApi,
            authRepository = authRepository,
            externalScope = applicationScope
        )

        contentRepository = SpotifyContentRepositoryImpl(
            spotifyApi = spotifyApi
        )
    }

    companion object {
        lateinit var instance: B4ddaxApplication
            private set
    }
}
