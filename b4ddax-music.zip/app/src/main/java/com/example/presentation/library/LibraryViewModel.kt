package com.example.presentation.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.AlbumModel
import com.example.domain.model.ArtistModel
import com.example.domain.model.PlaylistModel
import com.example.domain.model.TrackModel
import com.example.domain.repository.SpotifyAuthRepository
import com.example.domain.repository.SpotifyContentRepository
import com.example.domain.repository.SpotifyPlayerController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class LibraryTab {
    ALL,
    PLAYLISTS,
    LIKED_SONGS,
    ALBUMS,
    ARTISTS
}

data class LibraryUiState(
    val selectedTab: LibraryTab = LibraryTab.ALL,
    val playlists: List<PlaylistModel> = emptyList(),
    val likedSongs: List<TrackModel> = emptyList(),
    val albums: List<AlbumModel> = emptyList(),
    val artists: List<ArtistModel> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class LibraryViewModel(
    private val contentRepository: SpotifyContentRepository,
    private val playerController: SpotifyPlayerController,
    private val authRepository: SpotifyAuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LibraryUiState())
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()

    val playerState = playerController.playerState.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        playerController.getPlayerState()
    )

    val isAuthenticated = authRepository.isAuthenticated.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        authRepository.isAuthenticated.value
    )

    init {
        loadLibraryData()
    }

    fun loadLibraryData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            val playlistsRes = contentRepository.getUserPlaylists()
            val likedRes = contentRepository.getUserLikedSongs()
            val albumsRes = contentRepository.getUserSavedAlbums()
            val artistsRes = contentRepository.getUserFollowedArtists()

            _uiState.value = _uiState.value.copy(
                isLoading = false,
                playlists = playlistsRes.getOrDefault(emptyList()),
                likedSongs = likedRes.getOrDefault(emptyList()),
                albums = albumsRes.getOrDefault(emptyList()),
                artists = artistsRes.getOrDefault(emptyList())
            )
        }
    }

    fun selectTab(tab: LibraryTab) {
        _uiState.value = _uiState.value.copy(selectedTab = tab)
    }

    fun playTrack(track: TrackModel) {
        playerController.play(track.uri)
    }

    fun playContext(uri: String) {
        playerController.play(uri)
    }
}
