package com.example.presentation.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.AlbumModel
import com.example.domain.model.ArtistModel
import com.example.domain.model.PlaylistModel
import com.example.domain.model.TrackModel
import com.example.domain.repository.SpotifyContentRepository
import com.example.domain.repository.SpotifyPlayerController
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SearchCategory {
    ALL,
    SONGS,
    ARTISTS,
    ALBUMS,
    PLAYLISTS
}

data class SearchUiState(
    val query: String = "",
    val selectedCategory: SearchCategory = SearchCategory.ALL,
    val tracks: List<TrackModel> = emptyList(),
    val artists: List<ArtistModel> = emptyList(),
    val albums: List<AlbumModel> = emptyList(),
    val playlists: List<PlaylistModel> = emptyList(),
    val isSearching: Boolean = false,
    val errorMessage: String? = null
)

class SearchViewModel(
    private val contentRepository: SpotifyContentRepository,
    private val playerController: SpotifyPlayerController
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    val playerState = playerController.playerState.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        playerController.getPlayerState()
    )

    private var searchJob: Job? = null

    fun onQueryChange(newQuery: String) {
        _uiState.value = _uiState.value.copy(query = newQuery)
        searchJob?.cancel()

        if (newQuery.isBlank()) {
            _uiState.value = _uiState.value.copy(
                tracks = emptyList(),
                artists = emptyList(),
                albums = emptyList(),
                playlists = emptyList(),
                isSearching = false,
                errorMessage = null
            )
            return
        }

        searchJob = viewModelScope.launch {
            delay(400) // Debounce
            _uiState.value = _uiState.value.copy(isSearching = true, errorMessage = null)
            val result = contentRepository.search(newQuery.trim())
            if (result.isSuccess) {
                val data = result.getOrThrow()
                _uiState.value = _uiState.value.copy(
                    tracks = data.tracks,
                    artists = data.artists,
                    albums = data.albums,
                    playlists = data.playlists,
                    isSearching = false
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isSearching = false,
                    errorMessage = result.exceptionOrNull()?.localizedMessage
                )
            }
        }
    }

    fun onCategorySelect(category: SearchCategory) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
    }

    fun playTrack(track: TrackModel) {
        playerController.play(track.uri)
    }

    fun playContext(uri: String) {
        playerController.play(uri)
    }

    fun clearSearch() {
        _uiState.value = _uiState.value.copy(
            query = "",
            tracks = emptyList(),
            artists = emptyList(),
            albums = emptyList(),
            playlists = emptyList(),
            isSearching = false
        )
    }
}
