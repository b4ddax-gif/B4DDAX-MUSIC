package com.example.presentation.player

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.core.utils.TimeUtils
import com.example.domain.model.RepeatMode
import com.example.ui.theme.B4ddaxBlack
import com.example.ui.theme.B4ddaxBorder
import com.example.ui.theme.B4ddaxGreenAccent
import com.example.ui.theme.B4ddaxGreenPrimary
import com.example.ui.theme.B4ddaxRed
import com.example.ui.theme.B4ddaxSurface
import com.example.ui.theme.B4ddaxSurfaceElevated
import com.example.ui.theme.B4ddaxTextMuted
import com.example.ui.theme.B4ddaxTextPrimary
import com.example.ui.theme.B4ddaxTextSecondary

@Composable
fun FullPlayerScreen(
    viewModel: PlayerViewModel,
    onCollapse: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onCollapse() }

    val playerState by viewModel.playerState.collectAsState()
    val isLiked by viewModel.isLiked.collectAsState()
    val track = playerState.currentTrack

    var isUserDraggingSlider by remember { mutableStateOf(false) }
    var dragSliderPosition by remember { mutableFloatStateOf(0f) }

    val currentPosition = if (isUserDraggingSlider) {
        dragSliderPosition.toLong()
    } else {
        playerState.playbackPositionMs
    }

    val artworkScale by animateFloatAsState(
        targetValue = if (playerState.isPlaying) 1.0f else 0.94f,
        label = "art_scale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1B241C),
                        B4ddaxSurface,
                        B4ddaxBlack
                    )
                )
            )
            .testTag("full_player_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Top Bar with Collapse Down Arrow & Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onCollapse,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_collapse_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Collapse Player",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "PLAYING FROM SPOTIFY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = B4ddaxTextSecondary
                    )
                    if (track != null && track.album.isNotBlank()) {
                        Text(
                            text = track.album,
                            style = MaterialTheme.typography.labelMedium,
                            color = B4ddaxTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                IconButton(
                    onClick = { viewModel.openInSpotify() },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_open_spotify_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Open in Spotify",
                        tint = B4ddaxTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Large Album Artwork
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.88f)
                    .aspectRatio(1f)
                    .scale(artworkScale)
                    .shadow(16.dp, RoundedCornerShape(20.dp))
                    .clip(RoundedCornerShape(20.dp))
                    .background(B4ddaxSurfaceElevated)
                    .testTag("player_album_art"),
                contentAlignment = Alignment.Center
            ) {
                if (!track?.albumArtUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = track!!.albumArtUrl,
                        contentDescription = "Album cover",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = B4ddaxTextMuted,
                        modifier = Modifier.size(80.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Track Title, Artist, and Like Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track?.title ?: "No track playing",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = B4ddaxTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = track?.artist ?: "Select a song from Home or Search",
                        style = MaterialTheme.typography.titleMedium,
                        color = B4ddaxTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = { viewModel.toggleLike() },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_favorite_button")
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (isLiked) "Unlike" else "Like",
                        tint = if (isLiked) B4ddaxRed else Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Playback Seek Slider
            val maxSliderValue = if (playerState.durationMs > 0) playerState.durationMs.toFloat() else 1f
            val currentSliderValue = currentPosition.toFloat().coerceIn(0f, maxSliderValue)

            Slider(
                value = currentSliderValue,
                onValueChange = {
                    isUserDraggingSlider = true
                    dragSliderPosition = it
                },
                onValueChangeFinished = {
                    isUserDraggingSlider = false
                    viewModel.seekTo(dragSliderPosition.toLong())
                },
                valueRange = 0f..maxSliderValue,
                enabled = playerState.canSeek && playerState.durationMs > 0,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = B4ddaxGreenAccent,
                    inactiveTrackColor = B4ddaxBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("player_seek_slider")
            )

            // Duration labels (Elapsed / Total)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = TimeUtils.formatDurationMs(currentPosition),
                    style = MaterialTheme.typography.labelSmall,
                    color = B4ddaxTextSecondary
                )
                Text(
                    text = TimeUtils.formatDurationMs(playerState.durationMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = B4ddaxTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Playback Controls Row (Shuffle, Previous, Play/Pause, Next, Repeat)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shuffle Button
                IconButton(
                    onClick = { viewModel.toggleShuffle() },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_shuffle_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (playerState.isShuffling) B4ddaxGreenAccent else B4ddaxTextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Previous Button
                IconButton(
                    onClick = { viewModel.skipPrevious() },
                    enabled = playerState.canSkipPrevious,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_prev_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Previous",
                        tint = if (playerState.canSkipPrevious) Color.White else B4ddaxTextMuted,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Play / Pause Floating Hero Button
                Surface(
                    onClick = { viewModel.togglePlayPause() },
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .testTag("player_play_pause_hero_btn"),
                    color = Color.White,
                    shadowElevation = 8.dp
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                            tint = Color.Black,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                // Next Button
                IconButton(
                    onClick = { viewModel.skipNext() },
                    enabled = playerState.canSkipNext,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_next_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Next",
                        tint = if (playerState.canSkipNext) Color.White else B4ddaxTextMuted,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Repeat Button
                IconButton(
                    onClick = { viewModel.cycleRepeatMode() },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_repeat_btn")
                ) {
                    Icon(
                        imageVector = if (playerState.repeatMode == RepeatMode.TRACK) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        contentDescription = "Repeat",
                        tint = if (playerState.repeatMode != RepeatMode.OFF) B4ddaxGreenAccent else B4ddaxTextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Device Information Bar
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(B4ddaxSurfaceElevated)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("player_device_info"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Devices,
                    contentDescription = null,
                    tint = B4ddaxGreenAccent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (!playerState.deviceName.isNullOrBlank()) {
                        "Listening on ${playerState.deviceName}"
                    } else {
                        "Connected with Spotify App"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = B4ddaxTextPrimary
                )
            }

            // Playback restriction warning if any
            if (!playerState.playbackRestriction.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = playerState.playbackRestriction!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = B4ddaxRed,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
