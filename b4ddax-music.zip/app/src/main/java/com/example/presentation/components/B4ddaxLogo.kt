package com.example.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.B4ddaxGreenAccent
import com.example.ui.theme.B4ddaxGreenPrimary

@Composable
fun B4ddaxLogoIcon(
    modifier: Modifier = Modifier,
    size: Dp = 32.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .testTag("b4ddax_logo_icon"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height

            // 4 vertical animated spectrum bars that form an iconic B contour
            val barWidth = w * 0.16f
            val cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            val gradient = Brush.verticalGradient(
                colors = listOf(B4ddaxGreenAccent, B4ddaxGreenPrimary)
            )

            // Bar 1 (Left main pillar)
            drawRoundRect(
                brush = gradient,
                topLeft = Offset(w * 0.12f, h * 0.15f),
                size = Size(barWidth, h * 0.70f),
                cornerRadius = cornerRadius
            )

            // Bar 2 (Mid-high bar)
            drawRoundRect(
                brush = gradient,
                topLeft = Offset(w * 0.35f, h * 0.32f),
                size = Size(barWidth, h * 0.45f),
                cornerRadius = cornerRadius
            )

            // Bar 3 (Center dynamic beat)
            drawRoundRect(
                brush = gradient,
                topLeft = Offset(w * 0.58f, h * 0.18f),
                size = Size(barWidth, h * 0.62f),
                cornerRadius = cornerRadius
            )

            // Bar 4 (Right accent)
            drawRoundRect(
                brush = gradient,
                topLeft = Offset(w * 0.81f, h * 0.40f),
                size = Size(barWidth, h * 0.38f),
                cornerRadius = cornerRadius
            )
        }
    }
}

@Composable
fun B4ddaxBrandHeader(
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.testTag("b4ddax_brand_header"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        B4ddaxLogoIcon(size = 32.dp)
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "B4DDAX",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            ),
            color = Color.White
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = "MUSIC",
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.5.sp
            ),
            color = B4ddaxGreenAccent
        )
    }
}
