package com.example.presentation.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.B4ddaxApplication
import com.example.core.utils.IntentUtils
import com.example.presentation.components.MiniPlayer
import com.example.presentation.connection.SpotifyConnectionDialog
import com.example.presentation.home.HomeScreen
import com.example.presentation.home.HomeViewModel
import com.example.presentation.library.LibraryScreen
import com.example.presentation.library.LibraryViewModel
import com.example.presentation.player.FullPlayerScreen
import com.example.presentation.player.PlayerViewModel
import com.example.presentation.profile.ProfileScreen
import com.example.presentation.profile.ProfileViewModel
import com.example.ui.theme.B4ddaxBlack
import com.example.ui.theme.B4ddaxBorder
import com.example.ui.theme.B4ddaxGreenAccent
import com.example.ui.theme.B4ddaxGreenPrimary
import com.example.ui.theme.B4ddaxSurface
import com.example.ui.theme.B4ddaxTextMuted
import com.example.ui.theme.B4ddaxTextSecondary

@Composable
fun B4ddaxMainScreen(
    app: B4ddaxApplication = B4ddaxApplication.instance
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    // ViewModels instantiated via application container
    val homeViewModel = remember {
        HomeViewModel(app.playerController, app.contentRepository, app.authRepository)
    }
    val searchViewModel = remember {
        com.example.presentation.search.SearchViewModel(app.contentRepository, app.playerController)
    }
    val libraryViewModel = remember {
        LibraryViewModel(app.contentRepository, app.playerController, app.authRepository)
    }
    val profileViewModel = remember {
        ProfileViewModel(app.authRepository, app.playerController, app.preferencesDataStore)
    }
    val playerViewModel = remember {
        PlayerViewModel(app.playerController, app.contentRepository)
    }

    val playerState by app.playerController.playerState.collectAsState()
    val connectionState by app.playerController.connectionState.collectAsState()
    val clientId by app.authRepository.clientId.collectAsState()
    val redirectUri by app.authRepository.redirectUri.collectAsState()

    var isFullPlayerVisible by remember { mutableStateOf(false) }
    var isConnectionDialogVisible by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Persistent Mini Player above Navigation Bar
                    MiniPlayer(
                        playerState = playerState,
                        onMiniPlayerClick = { isFullPlayerVisible = true },
                        onPlayPauseClick = { app.playerController.togglePlayPause() },
                        onSkipNextClick = { app.playerController.skipNext() }
                    )

                    // Bottom Navigation Bar
                    NavigationBar(
                        containerColor = B4ddaxSurface,
                        tonalElevation = 8.dp,
                        modifier = Modifier
                            .height(64.dp)
                            .testTag("bottom_nav_bar")
                    ) {
                        Screen.bottomNavItems.forEach { screen ->
                            val selected = currentDestination?.route == screen.route
                            NavigationBarItem(
                                icon = {
                                    Icon(
                                        imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                        contentDescription = screen.title
                                    )
                                },
                                label = { Text(screen.title) },
                                selected = selected,
                                onClick = {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = B4ddaxGreenAccent,
                                    indicatorColor = B4ddaxGreenPrimary,
                                    unselectedIconColor = B4ddaxTextSecondary,
                                    unselectedTextColor = B4ddaxTextMuted
                                ),
                                modifier = Modifier.testTag("nav_item_${screen.route}")
                            )
                        }
                    }
                }
            },
            containerColor = B4ddaxBlack
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = homeViewModel,
                        onOpenPlayer = { isFullPlayerVisible = true },
                        onOpenConnectDialog = { isConnectionDialogVisible = true }
                    )
                }

                composable(Screen.Search.route) {
                    com.example.presentation.search.SearchScreen(
                        viewModel = searchViewModel
                    )
                }

                composable(Screen.Library.route) {
                    LibraryScreen(
                        viewModel = libraryViewModel,
                        onOpenConnectDialog = { isConnectionDialogVisible = true }
                    )
                }

                composable(Screen.Profile.route) {
                    ProfileScreen(
                        viewModel = profileViewModel,
                        onOpenConnectDialog = { isConnectionDialogVisible = true }
                    )
                }
            }
        }

        // Full Screen Player Overlay (animated enter/exit)
        AnimatedVisibility(
            visible = isFullPlayerVisible,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            FullPlayerScreen(
                viewModel = playerViewModel,
                onCollapse = { isFullPlayerVisible = false }
            )
        }

        // Spotify Connection Onboarding & Dialog
        if (isConnectionDialogVisible) {
            SpotifyConnectionDialog(
                connectionState = connectionState,
                clientId = clientId,
                redirectUri = redirectUri,
                onConnectClick = {
                    val authUrl = app.authRepository.getAuthorizationUrl()
                    IntentUtils.openCustomTab(context, authUrl)
                },
                onInstallSpotifyClick = {
                    app.playerController.installSpotify()
                },
                onOpenSpotifyClick = {
                    app.playerController.openSpotifyApp()
                },
                onUpdateCredentials = { newClientId, newRedirectUri ->
                    app.authRepository.updateCredentials(newClientId, newRedirectUri)
                },
                onDismiss = { isConnectionDialogVisible = false }
            )
        }
    }
}
