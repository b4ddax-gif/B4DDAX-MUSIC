package com.example.presentation.connection

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.domain.model.SpotifyConnectionState
import com.example.presentation.components.B4ddaxLogoIcon
import com.example.ui.theme.B4ddaxBorder
import com.example.ui.theme.B4ddaxGreenAccent
import com.example.ui.theme.B4ddaxGreenPrimary
import com.example.ui.theme.B4ddaxRed
import com.example.ui.theme.B4ddaxSurface
import com.example.ui.theme.B4ddaxSurfaceElevated
import com.example.ui.theme.B4ddaxSurfaceVariant
import com.example.ui.theme.B4ddaxTextMuted
import com.example.ui.theme.B4ddaxTextPrimary
import com.example.ui.theme.B4ddaxTextSecondary
import com.example.ui.theme.B4ddaxWarning

@Composable
fun SpotifyConnectionDialog(
    connectionState: SpotifyConnectionState,
    clientId: String,
    redirectUri: String,
    onConnectClick: () -> Unit,
    onInstallSpotifyClick: () -> Unit,
    onOpenSpotifyClick: () -> Unit,
    onUpdateCredentials: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var showDevSettings by remember { mutableStateOf(false) }
    var inputClientId by remember(clientId) { mutableStateOf(clientId) }
    var inputRedirectUri by remember(redirectUri) { mutableStateOf(redirectUri) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(24.dp))
                .testTag("spotify_connection_dialog"),
            color = B4ddaxSurface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Logo
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(B4ddaxSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    B4ddaxLogoIcon(size = 38.dp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Connect your Spotify",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = B4ddaxTextPrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Connect your Spotify account to control playback and explore your music.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = B4ddaxTextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Connection State Card
                ConnectionStateDetailCard(connectionState = connectionState)

                Spacer(modifier = Modifier.height(24.dp))

                // Primary Action Button based on state
                when (connectionState) {
                    SpotifyConnectionState.SPOTIFY_NOT_INSTALLED -> {
                        Button(
                            onClick = onInstallSpotifyClick,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("install_spotify_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = B4ddaxGreenPrimary),
                            shape = RoundedCornerShape(25.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Install Spotify", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }

                    SpotifyConnectionState.CONNECTING -> {
                        Button(
                            onClick = {},
                            enabled = false,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("connecting_spotify_button"),
                            shape = RoundedCornerShape(25.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = B4ddaxGreenAccent,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Connecting...", color = Color.White)
                        }
                    }

                    SpotifyConnectionState.CONNECTED -> {
                        Button(
                            onClick = onOpenSpotifyClick,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("open_spotify_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = B4ddaxGreenPrimary),
                            shape = RoundedCornerShape(25.dp)
                        ) {
                            Icon(Icons.Default.PlayCircle, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Open Spotify App", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }

                    else -> {
                        Button(
                            onClick = onConnectClick,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("connect_spotify_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = B4ddaxGreenPrimary),
                            shape = RoundedCornerShape(25.dp)
                        ) {
                            Text("Connect Spotify", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Developer / Custom Credentials Section Toggle
                TextButton(
                    onClick = { showDevSettings = !showDevSettings },
                    modifier = Modifier.testTag("toggle_dev_settings_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = B4ddaxTextMuted
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (showDevSettings) "Hide API Credentials" else "Configure Spotify Client ID",
                        style = MaterialTheme.typography.labelMedium,
                        color = B4ddaxTextMuted
                    )
                }

                if (showDevSettings) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        color = B4ddaxSurfaceElevated
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Developer Credentials",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = B4ddaxTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Never enter a Client Secret. Client ID is public and safe to use with PKCE.",
                                style = MaterialTheme.typography.bodySmall,
                                color = B4ddaxTextSecondary
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = inputClientId,
                                onValueChange = { inputClientId = it },
                                label = { Text("Spotify Client ID") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_client_id"),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = B4ddaxGreenAccent,
                                    unfocusedBorderColor = B4ddaxBorder,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = inputRedirectUri,
                                onValueChange = { inputRedirectUri = it },
                                label = { Text("Redirect URI") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_redirect_uri"),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = B4ddaxGreenAccent,
                                    unfocusedBorderColor = B4ddaxBorder,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    onUpdateCredentials(inputClientId, inputRedirectUri)
                                    showDevSettings = false
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("save_credentials_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = B4ddaxSurfaceVariant)
                            ) {
                                Text("Save & Apply", color = Color.White)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("close_connection_dialog_btn"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = B4ddaxTextSecondary),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Text("Close")
                }
            }
        }
    }
}

@Composable
private fun ConnectionStateDetailCard(connectionState: SpotifyConnectionState) {
    val (icon, tint, title, desc) = when (connectionState) {
        SpotifyConnectionState.NOT_CONNECTED ->
            Tuple4(
                Icons.Default.Info,
                B4ddaxWarning,
                "Ready to Connect",
                "Authorize B4DDAX Music to sync playback state and control Spotify remotely."
            )
        SpotifyConnectionState.CONNECTING ->
            Tuple4(
                Icons.Default.Refresh,
                B4ddaxGreenAccent,
                "Establishing Connection",
                "Connecting with the official Spotify service..."
            )
        SpotifyConnectionState.CONNECTED ->
            Tuple4(
                Icons.Default.CheckCircle,
                B4ddaxGreenAccent,
                "Successfully Connected",
                "Playback state is synchronized with Spotify. You can now select songs and albums to play."
            )
        SpotifyConnectionState.SPOTIFY_NOT_INSTALLED ->
            Tuple4(
                Icons.Default.Error,
                B4ddaxRed,
                "Spotify Not Found",
                "The official Spotify app is required on your device for companion playback control."
            )
        SpotifyConnectionState.AUTH_REQUIRED ->
            Tuple4(
                Icons.Default.Lock,
                B4ddaxWarning,
                "Authorization Required",
                "Tap Connect to grant read and playback control scopes via Spotify's secure login screen."
            )
        SpotifyConnectionState.PREMIUM_REQUIRED ->
            Tuple4(
                Icons.Default.Info,
                B4ddaxWarning,
                "Spotify Premium Required",
                "On-demand mobile track selection requires an active Spotify Premium subscription according to Spotify developer terms."
            )
        SpotifyConnectionState.CONNECTION_ERROR ->
            Tuple4(
                Icons.Default.Error,
                B4ddaxRed,
                "Connection Error",
                "Could not reach Spotify. Please ensure the Spotify app is running or check network connection."
            )
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .testTag("connection_state_detail_card"),
        color = B4ddaxSurfaceVariant
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier
                    .size(24.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = B4ddaxTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = B4ddaxTextSecondary
                )
            }
        }
    }
}

private data class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
