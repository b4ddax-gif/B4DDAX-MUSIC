package com.example.presentation.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.domain.model.AlbumModel
import com.example.domain.model.ArtistModel
import com.example.domain.model.PlaylistModel
import com.example.presentation.components.SectionHeader
import com.example.presentation.components.TrackListItem
import com.example.ui.theme.B4ddaxBorder
import com.example.ui.theme.B4ddaxGreenAccent
import com.example.ui.theme.B4ddaxGreenPrimary
import com.example.ui.theme.B4ddaxSurface
import com.example.ui.theme.B4ddaxSurfaceElevated
import com.example.ui.theme.B4ddaxSurfaceVariant
import com.example.ui.theme.B4ddaxTextMuted
import com.example.ui.theme.B4ddaxTextPrimary
import com.example.ui.theme.B4ddaxTextSecondary

@Composable
fun SearchScreen(
    viewModel: SearchViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val playerState by viewModel.playerState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("search_screen")
    ) {
        // Search Header Title
        Text(
            text = "Search",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = B4ddaxTextPrimary,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)
        )

        // Search Input Bar
        OutlinedTextField(
            value = uiState.query,
            onValueChange = { viewModel.onQueryChange(it) },
            placeholder = { Text("Songs, artists, albums, or playlists") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = B4ddaxTextSecondary
                )
            },
            trailingIcon = {
                if (uiState.query.isNotEmpty()) {
                    IconButton(
                        onClick = { viewModel.clearSearch() },
                        modifier = Modifier.testTag("clear_search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear search",
                            tint = B4ddaxTextSecondary
                        )
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("search_text_field"),
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = B4ddaxSurfaceVariant,
                unfocusedContainerColor = B4ddaxSurfaceVariant,
                focusedBorderColor = B4ddaxGreenAccent,
                unfocusedBorderColor = B4ddaxBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Category Filter Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(SearchCategory.values()) { category ->
                val selected = uiState.selectedCategory == category
                FilterChip(
                    selected = selected,
                    onClick = { viewModel.onCategorySelect(category) },
                    label = { Text(category.name.lowercase().replaceFirstChar { it.uppercase() }) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = B4ddaxGreenPrimary,
                        selectedLabelColor = Color.Black,
                        containerColor = B4ddaxSurfaceVariant,
                        labelColor = B4ddaxTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = B4ddaxBorder,
                        selectedBorderColor = B4ddaxGreenAccent,
                        enabled = true,
                        selected = selected
                    ),
                    modifier = Modifier.testTag("chip_${category.name}")
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        if (uiState.isSearching) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = B4ddaxGreenAccent)
            }
        }

        // Search Content or Explore Genres
        if (uiState.query.isBlank()) {
            BrowseGenresGrid(
                onGenreClick = { genre ->
                    viewModel.onQueryChange(genre)
                }
            )
        } else {
            SearchResultsList(
                uiState = uiState,
                currentTrackId = playerState.currentTrack?.id,
                isPlaying = playerState.isPlaying,
                onPlayTrack = { viewModel.playTrack(it) },
                onPlayContext = { viewModel.playContext(it) }
            )
        }
    }
}

@Composable
private fun SearchResultsList(
    uiState: SearchUiState,
    currentTrackId: String?,
    isPlaying: Boolean,
    onPlayTrack: (com.example.domain.model.TrackModel) -> Unit,
    onPlayContext: (String) -> Unit
) {
    val showAll = uiState.selectedCategory == SearchCategory.ALL

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Tracks / Songs
        if (showAll || uiState.selectedCategory == SearchCategory.SONGS) {
            if (uiState.tracks.isNotEmpty()) {
                item {
                    SectionHeader(title = "Songs")
                }
                items(uiState.tracks) { track ->
                    val isCurrent = currentTrackId == track.id
                    TrackListItem(
                        track = track,
                        isCurrentTrack = isCurrent,
                        isPlaying = isCurrent && isPlaying,
                        onClick = { onPlayTrack(track) }
                    )
                }
            }
        }

        // Artists
        if (showAll || uiState.selectedCategory == SearchCategory.ARTISTS) {
            if (uiState.artists.isNotEmpty()) {
                item {
                    SectionHeader(title = "Artists")
                }
                items(uiState.artists) { artist ->
                    ArtistListItem(
                        artist = artist,
                        onClick = { onPlayContext(artist.uri) }
                    )
                }
            }
        }

        // Albums
        if (showAll || uiState.selectedCategory == SearchCategory.ALBUMS) {
            if (uiState.albums.isNotEmpty()) {
                item {
                    SectionHeader(title = "Albums")
                }
                items(uiState.albums) { album ->
                    AlbumListItem(
                        album = album,
                        onClick = { onPlayContext(album.uri) }
                    )
                }
            }
        }

        // Playlists
        if (showAll || uiState.selectedCategory == SearchCategory.PLAYLISTS) {
            if (uiState.playlists.isNotEmpty()) {
                item {
                    SectionHeader(title = "Playlists")
                }
                items(uiState.playlists) { playlist ->
                    PlaylistListItem(
                        playlist = playlist,
                        onClick = { onPlayContext(playlist.uri) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ArtistListItem(
    artist: ArtistModel,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("artist_item_${artist.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(B4ddaxSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (!artist.imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = artist.imageUrl,
                    contentDescription = artist.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(Icons.Default.Person, contentDescription = null, tint = B4ddaxTextMuted)
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = artist.name,
                style = MaterialTheme.typography.titleMedium,
                color = B4ddaxTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Artist",
                style = MaterialTheme.typography.bodySmall,
                color = B4ddaxTextSecondary
            )
        }
    }
}

@Composable
private fun AlbumListItem(
    album: AlbumModel,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("album_item_${album.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(B4ddaxSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (!album.imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = album.imageUrl,
                    contentDescription = album.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(Icons.Default.Album, contentDescription = null, tint = B4ddaxTextMuted)
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = album.title,
                style = MaterialTheme.typography.titleMedium,
                color = B4ddaxTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Album • ${album.artist}",
                style = MaterialTheme.typography.bodySmall,
                color = B4ddaxTextSecondary
            )
        }
    }
}

@Composable
private fun PlaylistListItem(
    playlist: PlaylistModel,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("search_playlist_item_${playlist.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(B4ddaxSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (!playlist.imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = playlist.imageUrl,
                    contentDescription = playlist.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(Icons.Default.QueueMusic, contentDescription = null, tint = B4ddaxTextMuted)
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = playlist.title,
                style = MaterialTheme.typography.titleMedium,
                color = B4ddaxTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Playlist • By ${playlist.ownerName}",
                style = MaterialTheme.typography.bodySmall,
                color = B4ddaxTextSecondary
            )
        }
    }
}

@Composable
private fun BrowseGenresGrid(
    onGenreClick: (String) -> Unit
) {
    val genres = listOf(
        Pair("Hip-Hop", Color(0xFFBA4F27)),
        Pair("Electronic", Color(0xFF1E6088)),
        Pair("Rock", Color(0xFF8B2323)),
        Pair("Pop", Color(0xFF87327E)),
        Pair("R&B", Color(0xFF532E7C)),
        Pair("Chill & Lo-Fi", Color(0xFF275549)),
        Pair("Metal", Color(0xFF333333)),
        Pair("Classical", Color(0xFF755F2A))
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        item {
            Text(
                text = "Browse Categories",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = B4ddaxTextPrimary,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }

        // Two columns grid emulation
        val chunked = genres.chunked(2)
        items(chunked) { rowPair ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                for (item in rowPair) {
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(84.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onGenreClick(item.first) }
                            .testTag("genre_card_${item.first}"),
                        color = item.second
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            contentAlignment = Alignment.TopStart
                        ) {
                            Text(
                                text = item.first,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
                if (rowPair.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}
