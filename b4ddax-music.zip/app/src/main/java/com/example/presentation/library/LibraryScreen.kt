package com.example.presentation.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.domain.model.AlbumModel
import com.example.domain.model.ArtistModel
import com.example.domain.model.PlaylistModel
import com.example.presentation.components.SectionHeader
import com.example.presentation.components.TrackListItem
import com.example.ui.theme.B4ddaxBorder
import com.example.ui.theme.B4ddaxGreenAccent
import com.example.ui.theme.B4ddaxGreenPrimary
import com.example.ui.theme.B4ddaxRed
import com.example.ui.theme.B4ddaxSurfaceElevated
import com.example.ui.theme.B4ddaxSurfaceVariant
import com.example.ui.theme.B4ddaxTextMuted
import com.example.ui.theme.B4ddaxTextPrimary
import com.example.ui.theme.B4ddaxTextSecondary

@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    onOpenConnectDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val playerState by viewModel.playerState.collectAsState()
    val isAuthenticated by viewModel.isAuthenticated.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("library_screen")
    ) {
        // Library Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Your Library",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = B4ddaxTextPrimary
            )

            IconButton(
                onClick = { viewModel.loadLibraryData() },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("library_refresh_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh Library",
                    tint = B4ddaxTextSecondary
                )
            }
        }

        // Library Filter Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(LibraryTab.values()) { tab ->
                val selected = uiState.selectedTab == tab
                val label = when (tab) {
                    LibraryTab.ALL -> "All"
                    LibraryTab.PLAYLISTS -> "Playlists"
                    LibraryTab.LIKED_SONGS -> "Liked Songs"
                    LibraryTab.ALBUMS -> "Albums"
                    LibraryTab.ARTISTS -> "Artists"
                }

                FilterChip(
                    selected = selected,
                    onClick = { viewModel.selectTab(tab) },
                    label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = B4ddaxGreenPrimary,
                        selectedLabelColor = Color.Black,
                        containerColor = B4ddaxSurfaceVariant,
                        labelColor = B4ddaxTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = B4ddaxBorder,
                        selectedBorderColor = B4ddaxGreenAccent,
                        enabled = true,
                        selected = selected
                    ),
                    modifier = Modifier.testTag("library_tab_${tab.name}")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = B4ddaxGreenAccent)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                val tab = uiState.selectedTab
                val showAll = tab == LibraryTab.ALL

                // Liked Songs Quick Tile (shown in All or Liked Songs tab)
                if (showAll || tab == LibraryTab.LIKED_SONGS) {
                    item {
                        LikedSongsHeroItem(
                            count = uiState.likedSongs.size,
                            onClick = {
                                if (uiState.likedSongs.isNotEmpty()) {
                                    viewModel.playTrack(uiState.likedSongs.first())
                                }
                            }
                        )
                    }

                    if (tab == LibraryTab.LIKED_SONGS && uiState.likedSongs.isNotEmpty()) {
                        items(uiState.likedSongs) { track ->
                            val isCurrent = playerState.currentTrack?.id == track.id
                            TrackListItem(
                                track = track,
                                isCurrentTrack = isCurrent,
                                isPlaying = isCurrent && playerState.isPlaying,
                                onClick = { viewModel.playTrack(track) }
                            )
                        }
                    }
                }

                // Playlists
                if (showAll || tab == LibraryTab.PLAYLISTS) {
                    if (uiState.playlists.isNotEmpty()) {
                        item {
                            SectionHeader(title = "Playlists (${uiState.playlists.size})")
                        }
                        items(uiState.playlists) { playlist ->
                            LibraryPlaylistItem(
                                playlist = playlist,
                                onClick = { viewModel.playContext(playlist.uri) }
                            )
                        }
                    }
                }

                // Albums
                if (showAll || tab == LibraryTab.ALBUMS) {
                    if (uiState.albums.isNotEmpty()) {
                        item {
                            SectionHeader(title = "Albums (${uiState.albums.size})")
                        }
                        items(uiState.albums) { album ->
                            LibraryAlbumItem(
                                album = album,
                                onClick = { viewModel.playContext(album.uri) }
                            )
                        }
                    }
                }

                // Artists
                if (showAll || tab == LibraryTab.ARTISTS) {
                    if (uiState.artists.isNotEmpty()) {
                        item {
                            SectionHeader(title = "Artists (${uiState.artists.size})")
                        }
                        items(uiState.artists) { artist ->
                            LibraryArtistItem(
                                artist = artist,
                                onClick = { viewModel.playContext(artist.uri) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LikedSongsHeroItem(
    count: Int,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag("liked_songs_hero_item"),
        color = B4ddaxSurfaceElevated,
        tonalElevation = 3.dp
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF431F75)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Liked Songs",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = B4ddaxTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "$count songs",
                    style = MaterialTheme.typography.bodySmall,
                    color = B4ddaxTextSecondary
                )
            }
        }
    }
}

@Composable
private fun LibraryPlaylistItem(
    playlist: PlaylistModel,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("library_playlist_${playlist.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(B4ddaxSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (!playlist.imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = playlist.imageUrl,
                    contentDescription = playlist.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(Icons.Default.QueueMusic, contentDescription = null, tint = B4ddaxTextMuted)
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = playlist.title,
                style = MaterialTheme.typography.titleMedium,
                color = B4ddaxTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Playlist • ${playlist.ownerName}",
                style = MaterialTheme.typography.bodySmall,
                color = B4ddaxTextSecondary
            )
        }
    }
}

@Composable
private fun LibraryAlbumItem(
    album: AlbumModel,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("library_album_${album.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(B4ddaxSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (!album.imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = album.imageUrl,
                    contentDescription = album.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(Icons.Default.Album, contentDescription = null, tint = B4ddaxTextMuted)
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = album.title,
                style = MaterialTheme.typography.titleMedium,
                color = B4ddaxTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Album • ${album.artist}",
                style = MaterialTheme.typography.bodySmall,
                color = B4ddaxTextSecondary
            )
        }
    }
}

@Composable
private fun LibraryArtistItem(
    artist: ArtistModel,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("library_artist_${artist.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(B4ddaxSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (!artist.imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = artist.imageUrl,
                    contentDescription = artist.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(Icons.Default.Person, contentDescription = null, tint = B4ddaxTextMuted)
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = artist.name,
                style = MaterialTheme.typography.titleMedium,
                color = B4ddaxTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Artist",
                style = MaterialTheme.typography.bodySmall,
                color = B4ddaxTextSecondary
            )
        }
    }
}
