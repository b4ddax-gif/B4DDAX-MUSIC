package com.example.presentation.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.PlayerStateModel
import com.example.domain.model.RepeatMode
import com.example.domain.repository.SpotifyContentRepository
import com.example.domain.repository.SpotifyPlayerController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PlayerViewModel(
    private val playerController: SpotifyPlayerController,
    private val contentRepository: SpotifyContentRepository
) : ViewModel() {

    val playerState: StateFlow<PlayerStateModel> = playerController.playerState.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        playerController.getPlayerState()
    )

    private val _isLiked = MutableStateFlow(false)
    val isLiked: StateFlow<Boolean> = _isLiked.asStateFlow()

    fun togglePlayPause() {
        playerController.togglePlayPause()
    }

    fun skipNext() {
        playerController.skipNext()
    }

    fun skipPrevious() {
        playerController.skipPrevious()
    }

    fun seekTo(positionMs: Long) {
        playerController.seekTo(positionMs)
    }

    fun toggleShuffle() {
        val current = playerState.value.isShuffling
        playerController.setShuffle(!current)
    }

    fun cycleRepeatMode() {
        val nextMode = when (playerState.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.CONTEXT
            RepeatMode.CONTEXT -> RepeatMode.TRACK
            RepeatMode.TRACK -> RepeatMode.OFF
        }
        playerController.setRepeat(nextMode)
    }

    fun toggleLike() {
        val currentTrack = playerState.value.currentTrack ?: return
        val currentLiked = _isLiked.value
        viewModelScope.launch {
            val result = contentRepository.toggleLikeTrack(currentTrack.id, currentLiked)
            if (result.isSuccess) {
                _isLiked.value = result.getOrThrow()
            }
        }
    }

    fun openInSpotify() {
        val track = playerState.value.currentTrack
        if (track != null) {
            playerController.openSpotifyTrack(track.uri)
        } else {
            playerController.openSpotifyApp()
        }
    }
}
