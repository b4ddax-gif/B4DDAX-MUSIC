package com.example.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.utils.TimeUtils
import com.example.domain.model.PlaylistModel
import com.example.domain.model.TrackModel
import com.example.domain.repository.SpotifyAuthRepository
import com.example.domain.repository.SpotifyContentRepository
import com.example.domain.repository.SpotifyPlayerController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val greeting: String = TimeUtils.getTimeBasedGreeting(),
    val recentlyPlayed: List<TrackModel> = emptyList(),
    val featuredPlaylists: List<PlaylistModel> = emptyList(),
    val userPlaylists: List<PlaylistModel> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

class HomeViewModel(
    private val playerController: SpotifyPlayerController,
    private val contentRepository: SpotifyContentRepository,
    private val authRepository: SpotifyAuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val playerState = playerController.playerState.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        playerController.getPlayerState()
    )

    val connectionState = playerController.connectionState.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        playerController.connectionState.value
    )

    val errorMessage = playerController.errorMessage.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        playerController.errorMessage.value
    )

    val isAuthenticated = authRepository.isAuthenticated.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        authRepository.isAuthenticated.value
    )

    init {
        loadHomeData()
    }

    fun loadHomeData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            val recentResult = contentRepository.getRecentlyPlayed()
            val featuredResult = contentRepository.getFeaturedContent()
            val playlistsResult = contentRepository.getUserPlaylists()

            _uiState.value = _uiState.value.copy(
                isLoading = false,
                greeting = TimeUtils.getTimeBasedGreeting(),
                recentlyPlayed = recentResult.getOrDefault(emptyList()),
                featuredPlaylists = featuredResult.getOrDefault(emptyList()),
                userPlaylists = playlistsResult.getOrDefault(emptyList())
            )
        }
    }

    fun playTrack(track: TrackModel) {
        playerController.play(track.uri)
    }

    fun playPlaylist(playlist: PlaylistModel) {
        playerController.play(playlist.uri)
    }

    fun togglePlayPause() {
        playerController.togglePlayPause()
    }

    fun skipNext() {
        playerController.skipNext()
    }

    fun clearError() {
        playerController.clearError()
    }

    fun openSpotifyApp() {
        playerController.openSpotifyApp()
    }

    fun connectSpotify() {
        playerController.connect()
    }
}
