package com.example.presentation.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.domain.model.SpotifyConnectionState
import com.example.presentation.components.B4ddaxBrandHeader
import com.example.ui.theme.B4ddaxBorder
import com.example.ui.theme.B4ddaxGreenAccent
import com.example.ui.theme.B4ddaxGreenPrimary
import com.example.ui.theme.B4ddaxRed
import com.example.ui.theme.B4ddaxSurface
import com.example.ui.theme.B4ddaxSurfaceElevated
import com.example.ui.theme.B4ddaxSurfaceVariant
import com.example.ui.theme.B4ddaxTextMuted
import com.example.ui.theme.B4ddaxTextPrimary
import com.example.ui.theme.B4ddaxTextSecondary
import com.example.ui.theme.B4ddaxWarning

@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel,
    onOpenConnectDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val userProfile by viewModel.currentUserProfile.collectAsState()
    val isAuthenticated by viewModel.isAuthenticated.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val autoResume by viewModel.autoResumeFlow.collectAsState()
    val highQualitySync by viewModel.highQualitySyncFlow.collectAsState()

    var showAboutDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 100.dp)
            .testTag("profile_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            B4ddaxBrandHeader()
        }

        // Profile Avatar and Identity Card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(16.dp))
                .testTag("profile_card"),
            color = B4ddaxSurfaceElevated,
            tonalElevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Profile Avatar
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(B4ddaxSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    if (!userProfile?.profileImageUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = userProfile!!.profileImageUrl,
                            contentDescription = "Profile Avatar",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = B4ddaxGreenAccent,
                            modifier = Modifier.size(46.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Display Name
                Text(
                    text = userProfile?.displayName ?: if (isAuthenticated) "Spotify Listener" else "Guest Explorer",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = B4ddaxTextPrimary
                )

                // Product / Subscription badge
                if (userProfile?.product != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (userProfile!!.isPremium) B4ddaxGreenPrimary else Color(0xFF333333))
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (userProfile!!.isPremium) "SPOTIFY PREMIUM" else "SPOTIFY FREE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (userProfile!!.isPremium) Color.Black else Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Connection Action Buttons
                if (isAuthenticated) {
                    OutlinedButton(
                        onClick = { viewModel.disconnectSpotify() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("disconnect_spotify_btn"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = B4ddaxRed),
                        shape = RoundedCornerShape(23.dp)
                    ) {
                        Icon(Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Disconnect Spotify", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = onOpenConnectDialog,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("profile_connect_spotify_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = B4ddaxGreenPrimary),
                        shape = RoundedCornerShape(23.dp)
                    ) {
                        Text("Connect Spotify Account", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Playback & Sync Preferences
        Text(
            text = "PLAYBACK & COMPANION",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = B4ddaxTextSecondary,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
        )

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(14.dp)),
            color = B4ddaxSurfaceVariant
        ) {
            Column {
                SettingsSwitchRow(
                    icon = Icons.Default.Sync,
                    title = "Auto-Resume Playback",
                    subtitle = "Resume Spotify playback on app launch",
                    checked = autoResume,
                    onCheckedChange = { viewModel.setAutoResume(it) }
                )
                Divider(color = B4ddaxBorder, thickness = 0.5.dp)
                SettingsSwitchRow(
                    icon = Icons.Default.DarkMode,
                    title = "High Quality Artwork Sync",
                    subtitle = "Fetch 640px album sleeves where available",
                    checked = highQualitySync,
                    onCheckedChange = { viewModel.setHighQualitySync(it) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Spotify Integration & Credentials
        Text(
            text = "INTEGRATION",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = B4ddaxTextSecondary,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
        )

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(14.dp)),
            color = B4ddaxSurfaceVariant
        ) {
            Column {
                SettingsClickableRow(
                    icon = Icons.Default.Key,
                    title = "Spotify API Credentials",
                    subtitle = "View or customize Client ID and redirect URI",
                    onClick = onOpenConnectDialog
                )
                Divider(color = B4ddaxBorder, thickness = 0.5.dp)
                SettingsClickableRow(
                    icon = Icons.Default.Info,
                    title = "About B4DDAX Music",
                    subtitle = "Architecture & companion controller notes",
                    onClick = { showAboutDialog = true }
                )
                Divider(color = B4ddaxBorder, thickness = 0.5.dp)
                SettingsClickableRow(
                    icon = Icons.Default.Security,
                    title = "Privacy & Developer Policy",
                    subtitle = "Zero server storage & OAuth security",
                    onClick = { showPrivacyDialog = true }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // App Version
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "B4DDAX Music v1.0.0",
                style = MaterialTheme.typography.bodySmall,
                color = B4ddaxTextMuted
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Powered by Spotify Android App Remote & Web API",
                style = MaterialTheme.typography.labelSmall,
                color = B4ddaxTextMuted
            )
        }
    }

    if (showAboutDialog) {
        Dialog(onDismissRequest = { showAboutDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                color = B4ddaxSurfaceElevated
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "About B4DDAX Music",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = B4ddaxTextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "B4DDAX Music is an advanced Spotify companion and controller app. It connects directly with the official Spotify app and Web API using OAuth 2.0 PKCE.\n\nIt does not scrape, download, or host Spotify audio, and strictly complies with Spotify's developer terms.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = B4ddaxTextSecondary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { showAboutDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = B4ddaxGreenPrimary),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Got it", color = Color.Black)
                    }
                }
            }
        }
    }

    if (showPrivacyDialog) {
        Dialog(onDismissRequest = { showPrivacyDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                color = B4ddaxSurfaceElevated
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Privacy & Security",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = B4ddaxTextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "• No Spotify Client Secret is packaged in the APK.\n• Tokens are stored exclusively in local secure storage.\n• No analytics or personal information is transmitted to third-party backends.\n• Scopes requested are strictly limited to remote playback and library read.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = B4ddaxTextSecondary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { showPrivacyDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = B4ddaxGreenPrimary),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Close", color = Color.Black)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = B4ddaxGreenAccent,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = B4ddaxTextPrimary,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = B4ddaxTextSecondary
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = B4ddaxGreenPrimary,
                uncheckedTrackColor = B4ddaxSurface
            )
        )
    }
}

@Composable
private fun SettingsClickableRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = B4ddaxTextSecondary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = B4ddaxTextPrimary,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = B4ddaxTextSecondary
            )
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = B4ddaxTextMuted,
            modifier = Modifier.size(20.dp)
        )
    }
}
