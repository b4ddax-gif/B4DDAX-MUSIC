package com.example.presentation.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PreferencesDataStore
import com.example.domain.model.SpotifyConnectionState
import com.example.domain.model.UserProfileModel
import com.example.domain.repository.SpotifyAuthRepository
import com.example.domain.repository.SpotifyPlayerController
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProfileViewModel(
    private val authRepository: SpotifyAuthRepository,
    private val playerController: SpotifyPlayerController,
    private val preferencesDataStore: PreferencesDataStore
) : ViewModel() {

    val currentUserProfile: StateFlow<UserProfileModel?> = authRepository.currentUserProfile.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        authRepository.currentUserProfile.value
    )

    val isAuthenticated: StateFlow<Boolean> = authRepository.isAuthenticated.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        authRepository.isAuthenticated.value
    )

    val connectionState: StateFlow<SpotifyConnectionState> = playerController.connectionState.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        playerController.connectionState.value
    )

    val autoResumeFlow = preferencesDataStore.autoResumeFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        true
    )

    val highQualitySyncFlow = preferencesDataStore.highQualitySyncFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        true
    )

    val clientId: StateFlow<String> = authRepository.clientId.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        authRepository.clientId.value
    )

    val redirectUri: StateFlow<String> = authRepository.redirectUri.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        authRepository.redirectUri.value
    )

    fun refreshProfile() {
        viewModelScope.launch {
            authRepository.fetchCurrentUserProfile()
        }
    }

    fun setAutoResume(enabled: Boolean) {
        viewModelScope.launch {
            preferencesDataStore.setAutoResume(enabled)
        }
    }

    fun setHighQualitySync(enabled: Boolean) {
        viewModelScope.launch {
            preferencesDataStore.setHighQualitySync(enabled)
        }
    }

    fun disconnectSpotify() {
        viewModelScope.launch {
            playerController.disconnect()
            authRepository.logout()
        }
    }

    fun connectSpotify() {
        playerController.connect()
    }

    fun openSpotifyApp() {
        playerController.openSpotifyApp()
    }
}
