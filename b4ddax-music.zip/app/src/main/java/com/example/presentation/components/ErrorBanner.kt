package com.example.presentation.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.SpotifyConnectionState
import com.example.ui.theme.B4ddaxGreenAccent
import com.example.ui.theme.B4ddaxRed
import com.example.ui.theme.B4ddaxSurfaceElevated
import com.example.ui.theme.B4ddaxTextPrimary
import com.example.ui.theme.B4ddaxWarning

@Composable
fun ErrorBanner(
    message: String?,
    onDismiss: () -> Unit,
    onOpenSpotify: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = !message.isNullOrBlank(),
        modifier = modifier
    ) {
        if (message == null) return@AnimatedVisibility

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(10.dp))
                .testTag("error_banner"),
            color = B4ddaxSurfaceElevated,
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = B4ddaxWarning,
                    modifier = Modifier.size(20.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = B4ddaxTextPrimary,
                    modifier = Modifier.weight(1f)
                )

                if (onOpenSpotify != null && message.contains("Open Spotify", ignoreCase = true)) {
                    TextButton(
                        onClick = onOpenSpotify,
                        colors = ButtonDefaults.textButtonColors(contentColor = B4ddaxGreenAccent),
                        modifier = Modifier.testTag("error_open_spotify_button")
                    ) {
                        Text("Open", fontWeight = FontWeight.Bold)
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(36.dp).testTag("error_dismiss_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss",
                        tint = Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ConnectionStatusBar(
    connectionState: SpotifyConnectionState,
    onConnectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (connectionState == SpotifyConnectionState.CONNECTED) return

    val (bgColor, iconColor, statusText, actionText) = when (connectionState) {
        SpotifyConnectionState.NOT_CONNECTED ->
            Tuple4(Color(0xFF242424), B4ddaxWarning, "Spotify Not Connected", "Connect")
        SpotifyConnectionState.CONNECTING ->
            Tuple4(Color(0xFF242424), B4ddaxGreenAccent, "Connecting to Spotify...", null)
        SpotifyConnectionState.AUTH_REQUIRED ->
            Tuple4(Color(0xFF2B2012), B4ddaxWarning, "Spotify Login Required", "Authorize")
        SpotifyConnectionState.SPOTIFY_NOT_INSTALLED ->
            Tuple4(Color(0xFF331616), B4ddaxRed, "Spotify App Not Installed", "Install")
        SpotifyConnectionState.PREMIUM_REQUIRED ->
            Tuple4(Color(0xFF2B2012), B4ddaxWarning, "Spotify Premium Required for full control", "Learn More")
        SpotifyConnectionState.CONNECTION_ERROR ->
            Tuple4(Color(0xFF331616), B4ddaxRed, "Connection Problem", "Retry")
        else ->
            Tuple4(Color(0xFF242424), Color.Gray, "", null)
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .testTag("connection_status_bar"),
        color = bgColor
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(iconColor)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelMedium,
                    color = B4ddaxTextPrimary,
                    maxLines = 1
                )
            }

            if (actionText != null) {
                TextButton(
                    onClick = onConnectClick,
                    colors = ButtonDefaults.textButtonColors(contentColor = B4ddaxGreenAccent),
                    modifier = Modifier.testTag("connection_status_action_btn")
                ) {
                    Text(
                        text = actionText,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

private data class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
