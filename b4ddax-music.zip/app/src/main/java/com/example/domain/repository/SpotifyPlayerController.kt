package com.example.domain.repository

import com.example.domain.model.PlayerStateModel
import com.example.domain.model.RepeatMode
import com.example.domain.model.SpotifyConnectionState
import kotlinx.coroutines.flow.StateFlow

interface SpotifyPlayerController {
    val connectionState: StateFlow<SpotifyConnectionState>
    val playerState: StateFlow<PlayerStateModel>
    val isSpotifyInstalled: Boolean
    val errorMessage: StateFlow<String?>

    fun connect()
    fun disconnect()
    fun play(uri: String)
    fun pause()
    fun resume()
    fun skipNext()
    fun skipPrevious()
    fun seekTo(positionMs: Long)
    fun togglePlayPause()
    fun setShuffle(enabled: Boolean)
    fun setRepeat(mode: RepeatMode)
    fun getPlayerState(): PlayerStateModel
    fun subscribeToPlayerState()
    fun clearError()
    fun openSpotifyApp()
    fun openSpotifyTrack(uri: String)
    fun installSpotify()
}
