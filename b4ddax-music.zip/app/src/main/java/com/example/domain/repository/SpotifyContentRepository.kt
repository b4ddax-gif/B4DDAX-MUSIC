package com.example.domain.repository

import com.example.domain.model.AlbumModel
import com.example.domain.model.ArtistModel
import com.example.domain.model.PlaylistModel
import com.example.domain.model.TrackModel

data class SearchResults(
    val tracks: List<TrackModel> = emptyList(),
    val artists: List<ArtistModel> = emptyList(),
    val albums: List<AlbumModel> = emptyList(),
    val playlists: List<PlaylistModel> = emptyList()
)

interface SpotifyContentRepository {
    suspend fun search(query: String): Result<SearchResults>
    suspend fun getRecentlyPlayed(): Result<List<TrackModel>>
    suspend fun getFeaturedContent(): Result<List<PlaylistModel>>
    suspend fun getUserPlaylists(): Result<List<PlaylistModel>>
    suspend fun getUserLikedSongs(): Result<List<TrackModel>>
    suspend fun getUserSavedAlbums(): Result<List<AlbumModel>>
    suspend fun getUserFollowedArtists(): Result<List<ArtistModel>>
    suspend fun toggleLikeTrack(trackId: String, currentlyLiked: Boolean): Result<Boolean>
}
