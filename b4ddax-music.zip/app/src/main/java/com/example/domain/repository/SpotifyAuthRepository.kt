package com.example.domain.repository

import com.example.domain.model.UserProfileModel
import kotlinx.coroutines.flow.StateFlow

interface SpotifyAuthRepository {
    val isAuthenticated: StateFlow<Boolean>
    val currentUserProfile: StateFlow<UserProfileModel?>
    val clientId: StateFlow<String>
    val redirectUri: StateFlow<String>

    fun getAuthorizationUrl(): String
    suspend fun handleAuthCallbackUri(uriString: String): Result<Boolean>
    suspend fun refreshAccessToken(): Result<String>
    suspend fun fetchCurrentUserProfile(): Result<UserProfileModel>
    suspend fun logout()
    fun updateCredentials(clientId: String, redirectUri: String)
    fun getAccessToken(): String?
}
