package com.example.domain.model

enum class SpotifyConnectionState {
    NOT_CONNECTED,
    CONNECTING,
    CONNECTED,
    SPOTIFY_NOT_INSTALLED,
    AUTH_REQUIRED,
    PREMIUM_REQUIRED,
    CONNECTION_ERROR
}

enum class RepeatMode {
    OFF,
    CONTEXT, // Repeat playlist or album
    TRACK    // Repeat single track
}

data class TrackModel(
    val id: String,
    val uri: String,
    val title: String,
    val artist: String,
    val artistUri: String? = null,
    val album: String,
    val albumArtUrl: String?,
    val durationMs: Long,
    val isPlayable: Boolean = true,
    val isLiked: Boolean = false
)

data class ArtistModel(
    val id: String,
    val uri: String,
    val name: String,
    val imageUrl: String?,
    val genres: List<String> = emptyList(),
    val followersCount: Int = 0
)

data class AlbumModel(
    val id: String,
    val uri: String,
    val title: String,
    val artist: String,
    val imageUrl: String?,
    val releaseDate: String? = null,
    val totalTracks: Int = 0
)

data class PlaylistModel(
    val id: String,
    val uri: String,
    val title: String,
    val description: String?,
    val imageUrl: String?,
    val ownerName: String = "Spotify",
    val totalTracks: Int = 0
)

data class PlayerStateModel(
    val currentTrack: TrackModel? = null,
    val isPlaying: Boolean = false,
    val playbackPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isShuffling: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val canSkipNext: Boolean = true,
    val canSkipPrevious: Boolean = true,
    val canSeek: Boolean = true,
    val deviceName: String? = null,
    val deviceType: String? = null,
    val playbackRestriction: String? = null,
    val lastUpdatedTimestamp: Long = System.currentTimeMillis()
) {
    val progressFraction: Float
        get() = if (durationMs > 0) (playbackPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
}

data class UserProfileModel(
    val id: String,
    val displayName: String,
    val email: String? = null,
    val product: String? = null, // "premium" or "free"
    val profileImageUrl: String? = null,
    val followersCount: Int = 0,
    val country: String? = null
) {
    val isPremium: Boolean
        get() = product?.equals("premium", ignoreCase = true) == true
}
