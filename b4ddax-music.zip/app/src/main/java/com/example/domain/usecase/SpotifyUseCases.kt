package com.example.domain.usecase

import com.example.domain.model.PlayerStateModel
import com.example.domain.repository.SearchResults
import com.example.domain.repository.SpotifyContentRepository
import com.example.domain.repository.SpotifyPlayerController
import kotlinx.coroutines.flow.StateFlow

class GetPlaybackStateUseCase(
    private val playerController: SpotifyPlayerController
) {
    operator fun invoke(): StateFlow<PlayerStateModel> = playerController.playerState
}

class PlayTrackUseCase(
    private val playerController: SpotifyPlayerController
) {
    operator fun invoke(uri: String) {
        playerController.play(uri)
    }
}

class SearchSpotifyUseCase(
    private val contentRepository: SpotifyContentRepository
) {
    suspend operator fun invoke(query: String): Result<SearchResults> {
        return contentRepository.search(query)
    }
}

class ConnectSpotifyUseCase(
    private val playerController: SpotifyPlayerController
) {
    operator fun invoke() {
        playerController.connect()
    }
}
