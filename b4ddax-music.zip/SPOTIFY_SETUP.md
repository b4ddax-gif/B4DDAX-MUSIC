# B4DDAX Music — Spotify Integration & Developer Setup Guide

This guide explains how to register your app with Spotify and configure your **Spotify Client ID** and **Redirect URI** for B4DDAX Music.

---

## 1. Important Spotify Developer Policies & Architecture

- **Companion App Architecture**: B4DDAX Music is a companion and controller app. It connects to the official Spotify Android app and Spotify Web API via authorized OAuth flows and playback controls. It does **not** download, scrape, re-stream, cache, or modify Spotify audio files.
- **No Client Secret in APK**: Mobile applications are public clients. As mandated by Spotify's Security & Authentication Guidelines, **NEVER embed the Spotify Client Secret in the Android app, repository, or build files**. B4DDAX Music uses **OAuth 2.0 with PKCE (Proof Key for Code Exchange)** and the **Spotify App Remote / Media Session architecture**, which requires only the public `Client ID` and cryptographic code verifiers.

---

## 2. Setting Up Your Spotify Developer Dashboard

1. Navigate to the [Spotify Developer Dashboard](https://developer.spotify.com/dashboard) and log in with your Spotify account.
2. Click **Create an App**.
3. Fill in the App Details:
   - **App name**: `B4DDAX Music`
   - **App description**: `Companion and remote controller app for Spotify playback and library exploration.`
   - **Redirect URI**: Add:
     ```
     b4ddax://callback
     ```
   - Select **Web API** and **Android SDK** under *Which API/SDKs are you planning to use?*
4. Under **Android Packages**:
   - **Package name**: `com.aistudio.b4ddaxmusic.kmtvz`
   - **SHA-1 fingerprint**:
     To get your debug signing key fingerprint on your development machine, run:
     ```bash
     keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
     ```
     Copy the **SHA-1** hex string and paste it into the Spotify Developer Dashboard.
5. Click **Save**.
6. Copy your **Client ID** (a 32-character hexadecimal string).

---

## 3. Where to Enter the Spotify Client ID & Redirect URI

### Option A: In the `.env` file (Recommended)

Edit the `.env` file in the root directory of the project:

```properties
SPOTIFY_CLIENT_ID=your_actual_32_character_client_id_here
SPOTIFY_REDIRECT_URI=b4ddax://callback
```

When building, the Secrets Gradle Plugin will inject `SPOTIFY_CLIENT_ID` and `SPOTIFY_REDIRECT_URI` into `BuildConfig`:
- `BuildConfig.SPOTIFY_CLIENT_ID`
- `BuildConfig.SPOTIFY_REDIRECT_URI`

### Option B: In-App Settings

You can also enter or update your Spotify Client ID and Redirect URI directly inside the app:
1. Open **B4DDAX Music**.
2. Tap the **Profile** tab.
3. Open the **Spotify Connection** or **Developer Settings** section.
4. Enter your Client ID and tap **Save & Connect**.

---

## 4. Minimum Scopes Requested

B4DDAX Music strictly requests the minimal permissions required for music control and library discovery:

- `app-remote-control`: Connect to and control the Spotify app installed on device.
- `user-read-currently-playing`: Fetch the active track, playback progress, and artist info.
- `user-read-playback-state`: Synchronize full playback state, repeat, and shuffle flags.
- `user-modify-playback-state`: Play, pause, skip, seek, and toggle repeat/shuffle.
- `playlist-read-private`: Browse your personal playlists.
- `playlist-read-collaborative`: Browse collaborative playlists.
- `user-library-read`: Access saved tracks (Liked Songs) and saved albums.

---

## 5. Playback & Spotify Premium Notes

- **Spotify Premium**: Full playback control via Spotify App Remote / Connect requires Spotify Premium according to Spotify's Terms of Service. If a Free tier user attempts to play on demand, Spotify restricts track selection; the app detects this state (`PREMIUM_REQUIRED` or playback restriction) and prompts the user gracefully.
- **Active Device**: Spotify Connect requires an active playback device (such as the Spotify app on your phone, desktop, or Spotify Connect speaker). If no active device is found, B4DDAX Music displays a helpful action button: *"Open Spotify to start playback"*.
