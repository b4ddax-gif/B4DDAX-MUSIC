# B4DDAX Music 🎵

A production-quality Android companion and remote playback controller for Spotify, crafted with **Kotlin**, **Jetpack Compose**, and **Material 3**.

> **IMPORTANT NOTICE:**  
> B4DDAX Music is an official companion and playback controller for Spotify. It is **NOT** an independent Spotify music streaming or audio ripping service. It interacts directly with the official Spotify Android app and Spotify Web API using official OAuth 2.0 PKCE. It **never** downloads, extracts, modifies, or stores Spotify audio streams, and strictly follows Spotify's Developer Terms of Service and Policy Guidelines.

---

## 1. Project Overview

B4DDAX Music brings a minimalist, cinematic dark music experience to your device. It functions as a lightweight companion that stays synchronized with the official Spotify player running on your Android device or Spotify Connect network (smart speakers, desktop, etc.).

Key Highlights:
- **Clean Architecture & MVVM**: Unidirectional data flow from UI -> ViewModels -> Use Cases -> Repositories -> Spotify Controller.
- **Pure OAuth 2.0 PKCE**: Zero Client Secret in the APK. Safe, modern, and RFC 7636 compliant.
- **Deep Spotify Player Integration**: Real-time track progress, play, pause, seek, skip next/previous, shuffle, repeat, and like controls.
- **Adaptive M3 Dark Design**: Deep `#090909` charcoal background, `#151515` cards, and vibrant `#1DB954` accents.
- **Persistent Mini-Player**: Floats effortlessly above bottom navigation with instant expansion to the full-screen immersive player.
- **Zero Firebase / Zero Cloud Backend Required**: Pure local companion architecture that builds cleanly out-of-the-box.

---

## 2. Features

### 🏠 Home Screen
- Contextual greeting based on time of day (*Good morning*, *Good afternoon*, *Good evening*).
- Active **Hero Now-Playing Card** with direct quick playback controls.
- **Recently Played** tracks and quick playlist tiles.
- Curated & Featured recommendations from Spotify's public discovery catalog.

### 🔍 Search
- Instant search across **Songs**, **Artists**, **Albums**, and **Playlists**.
- Filter pills to isolate content types.
- Genre exploration grid (*Hip-Hop, Electronic, Rock, R&B, Chill & Lo-Fi, etc.*) when the search bar is empty.
- Tapping any track sends instant playback commands to Spotify.

### 🎧 Now Playing (Full-Screen Player)
- Full-screen immersion with ambient gradient backdrops.
- Dynamic artwork scaling based on playback state.
- Track title, artist, album, and like button.
- Scrubbable seek slider with real-time minute/second time formatting.
- Shuffle, previous, play/pause (68dp hero target), next, repeat cycle (off / context / track).
- Active device indicator (*"Listening on Pixel 8 Pro"*, *"Listening on Living Room Speaker"*).
- Graceful restriction handling: if Spotify restricts a command, the control is disabled with clear feedback.

### 🎼 Mini Player
- Persistent bottom bar displayed across screens during active playback.
- Top synchronized linear progress indicator.
- Fast tap-to-expand transition into the full-screen player.

### 📚 Library
- Filter pills: **All**, **Playlists**, **Liked Songs**, **Albums**, **Artists**.
- Instant access to saved Spotify library items.
- Real-time refresh from Spotify Web API.

### 👤 Profile & Developer Settings
- User Spotify avatar, display name, account tier (*Premium* / *Free*), and country.
- In-app Developer Credentials panel to test custom Spotify Client IDs and Redirect URIs without rebuilding.
- Spotify Disconnect / Re-authorize action.
- Playback & synchronization preferences.

---

## 3. Architecture

B4DDAX Music follows strict **Android MVVM + Clean Architecture**:

```
UI (Jetpack Compose M3 Screens & Components)
   │
   ▼
ViewModels (StateFlow, viewModelScope, Coroutines)
   │
   ▼
Domain Layer (Use Cases, Models, Repository Interfaces)
   │
   ▼
Data Layer (SpotifyPlayerRepositoryImpl, SpotifyAuthRepositoryImpl, PreferencesDataStore)
   │
   ▼
Spotify Core (Spotify API via Retrofit/OkHttp, PKCE OAuth, Android Intent/MediaSession)
```

### Directory Structure
```
app/src/main/java/com/example/
├── B4ddaxApplication.kt
├── MainActivity.kt
├── core/
│   ├── config/          # Spotify endpoints & minimal required scopes
│   ├── network/         # Retrofit API, Moshi DTOs, AuthInterceptor
│   ├── security/        # RFC 7636 PKCE generator, Secure TokenStorage
│   └── utils/           # IntentUtils (package checks, Play Store, CustomTabs)
├── data/
│   ├── local/           # PreferencesDataStore (DataStore Preferences)
│   └── repository/      # SpotifyAuthRepositoryImpl, SpotifyPlayerRepositoryImpl, ContentRepositoryImpl
├── domain/
│   ├── model/           # TrackModel, AlbumModel, PlayerStateModel, UserProfileModel
│   ├── repository/      # SpotifyPlayerController, SpotifyAuthRepository, SpotifyContentRepository
│   └── usecase/         # PlayTrackUseCase, SearchSpotifyUseCase, GetPlaybackStateUseCase
├── presentation/
│   ├── components/      # B4ddaxLogo, MiniPlayer, TrackListItem, SectionHeader, ErrorBanner
│   ├── home/            # HomeScreen, HomeViewModel
│   ├── search/          # SearchScreen, SearchViewModel
│   ├── player/          # FullPlayerScreen, PlayerViewModel
│   ├── library/         # LibraryScreen, LibraryViewModel
│   ├── profile/         # ProfileScreen, ProfileViewModel
│   ├── connection/      # SpotifyConnectionDialog
│   └── navigation/      # Screen routes, B4ddaxMainScreen scaffold
└── ui/theme/            # B4DDAX dark theme color palette, typography, shapes
```

---

## 4. How to Create a Spotify Developer Application

1. Open your browser and navigate to the [Spotify Developer Dashboard](https://developer.spotify.com/dashboard).
2. Log in with your Spotify credentials.
3. Click the **Create an App** button in the upper right.
4. Fill in:
   - **App name**: `B4DDAX Music`
   - **App description**: `Companion and remote controller app for Spotify playback and library exploration.`
   - **Redirect URI**: `b4ddax://callback`
   - **Which API/SDKs are you planning to use?**: Select **Web API** and **Android SDK**.
5. Accept Spotify's Developer Terms and click **Save**.

---

## 5. How to Configure Spotify Client ID

Copy your 32-character **Client ID** from your Spotify Developer Dashboard.

### Method 1: In the `.env` file (Build Time)
Edit the `.env` file in the project root:
```properties
SPOTIFY_CLIENT_ID=your_32_character_client_id_here
SPOTIFY_REDIRECT_URI=b4ddax://callback
```

### Method 2: Inside the App (Runtime)
You don't need to rebuild the APK to test!
1. Launch **B4DDAX Music**.
2. Tap the **Profile** tab.
3. Tap **Spotify API Credentials** (or tap **Connect** in the banner).
4. Tap **Configure Spotify Client ID**.
5. Paste your Client ID and tap **Save & Apply**.

---

## 6. How to Configure Redirect URI

In your Spotify Developer Dashboard:
1. Open your app settings.
2. Under **Redirect URIs**, add:
   ```
   b4ddax://callback
   ```
3. Save the changes.

---

## 7. How to Add Android Package Name

In the Spotify Developer Dashboard under **Android Packages**:
- **Package name**: `com.aistudio.b4ddaxmusic.kmtvz`

---

## 8. How to Add Android App Fingerprint (SHA-1)

To obtain your SHA-1 fingerprint for debug builds:

### On Linux / macOS:
```bash
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```

### From the Project Directory:
```bash
keytool -list -v -keystore debug.keystore -alias androiddebugkey -storepass android -keypass android
```

Copy the **SHA-1** fingerprint line (e.g. `AA:BB:CC:...`) and paste it into the **SHA-1 Fingerprints** field in your Spotify Developer Dashboard.

---

## 9. How to Install Spotify on the Test Device

B4DDAX Music detects whether Spotify is installed on the device.
- If Spotify is missing, the app displays an **Install Spotify** button.
- Tapping **Install Spotify** opens the official Spotify page directly in the Google Play Store (`market://details?id=com.spotify.music`).
- Alternatively, search for **Spotify** in the Google Play Store on your device or emulator and install it.

---

## 10. How to Authenticate

1. In B4DDAX Music, tap **Connect Spotify** (available from the Home banner, Profile screen, or the onboarding dialog).
2. The app launches Spotify's official authorization screen in Chrome Custom Tabs using **OAuth 2.0 PKCE**.
3. Review the minimal scopes requested:
   - `app-remote-control`
   - `user-read-currently-playing`
   - `user-read-playback-state`
   - `user-modify-playback-state`
   - `playlist-read-private`
   - `playlist-read-collaborative`
   - `user-library-read`
   - `user-read-recently-played`
4. Tap **Agree**.
5. Spotify redirects back to `b4ddax://callback`. The app securely exchanges the authorization code for an access token without exposing any secret.

---

## 11. How to Test Playback

1. Open the official Spotify app and log in.
2. Start playing any track or open B4DDAX Music.
3. In B4DDAX Music:
   - Browse **Home** or **Search** for a track or playlist.
   - Tap any track card.
   - The track will immediately begin playing through Spotify.
   - Use the **Mini-Player** or open the **Full-Screen Player** to pause, resume, seek, or skip tracks.
4. If no device is currently active, B4DDAX Music will display:
   *"No active Spotify device found. Open Spotify to start playback."*
   Tap **Open** to awaken playback.

---

## 12. Spotify Premium Requirements

According to Spotify's official Developer Guidelines:
- **Spotify Premium Users**: Have complete on-demand playback control (selecting specific tracks, skipping without limits, seeking).
- **Spotify Free Users**: Spotify restricts mobile on-demand track playback to shuffle mode. When a Free user selects a specific track, Spotify may restrict playback; B4DDAX Music identifies this restriction (`PREMIUM_REQUIRED`) and informs the user rather than failing silently.

---

## 13. Spotify Policy Limitations

- **No Audio Downloads**: Spotify's Terms of Service strictly forbid downloading, scraping, or saving Spotify audio tracks.
- **No Background Audio Hijacking**: Audio streams originate from Spotify's official app and Spotify Connect devices.
- **No Proprietary Brand Copying**: B4DDAX Music uses an original geometric brand logo and original UI components rather than copying Spotify's trademarked logos or proprietary artwork.

---

## 14. Security Notes

- **NO CLIENT SECRET**: Never store a Spotify Client Secret inside an Android APK. Anyone can decompile an APK and extract secrets. B4DDAX Music exclusively uses **OAuth 2.0 PKCE (RFC 7636)**, which is mathematically secure for public clients.
- **Encrypted Local Tokens**: Access and refresh tokens are stored exclusively on-device in private shared preferences.
- **Logcat Redaction**: Sensitive Authorization headers and token payloads are omitted from HTTP logging in all builds.

---

## 15. GitHub Actions Build Instructions

A ready-to-use GitHub Actions workflow is provided in `.github/workflows/build.yml`.

### Workflow Steps:
1. **Checkout**: Checks out the repository.
2. **JDK 17 Setup**: Configures Temurin JDK 17.
3. **Gradle Cache**: Uses `gradle/actions/setup-gradle` for fast builds.
4. **Assemble Debug**: Runs `gradle assembleDebug --stacktrace`.
5. **Artifact Upload**: Uploads `b4ddax-music-debug-apk` to GitHub Actions artifacts.

To run locally:
```bash
./gradlew assembleDebug
```
The resulting APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`
